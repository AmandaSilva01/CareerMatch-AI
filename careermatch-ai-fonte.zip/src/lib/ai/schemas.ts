import { z } from "zod";

/**
 * Shared AI contracts — used by the server AI service and by the UI.
 * All schemas are strict-compatible (every property required, nullable for optional).
 */

export const ParsedJobSchema = z.object({
  jobTitle: z.string(),
  company: z.string().nullable(),
  location: z.string().nullable(),
  workModel: z.string().nullable(),
  seniority: z.string().nullable(),
  salaryRange: z.string().nullable(),
  responsibilities: z.array(z.string()),
  requiredSkills: z.array(z.string()),
  desiredSkills: z.array(z.string()),
  technicalSkills: z.array(z.string()),
  softSkills: z.array(z.string()),
  languages: z.array(z.string()),
  keywords: z.array(z.string()),
});
export type ParsedJob = z.infer<typeof ParsedJobSchema>;

export const ParsedExperienceSchema = z.object({
  company: z.string(),
  role: z.string(),
  startDate: z.string().nullable(),
  endDate: z.string().nullable(),
  isCurrent: z.boolean(),
  description: z.string().nullable(),
  achievements: z.array(z.string()),
});
export const ParsedEducationSchema = z.object({
  institution: z.string(),
  course: z.string(),
  degree: z.string().nullable(),
  startDate: z.string().nullable(),
  endDate: z.string().nullable(),
});
export const ParsedResumeSchema = z.object({
  fullName: z.string().nullable(),
  email: z.string().nullable(),
  phone: z.string().nullable(),
  city: z.string().nullable(),
  linkedin: z.string().nullable(),
  github: z.string().nullable(),
  portfolio: z.string().nullable(),
  headline: z.string().nullable(),
  summary: z.string().nullable(),
  experiences: z.array(ParsedExperienceSchema),
  education: z.array(ParsedEducationSchema),
  technicalSkills: z.array(z.string()),
  tools: z.array(z.string()),
  softSkills: z.array(z.string()),
  languages: z.array(z.string()),
  certifications: z.array(z.string()),
});
export type ParsedResume = z.infer<typeof ParsedResumeSchema>;

export const MatchCategorySchema = z.object({
  key: z.enum(["experience", "technicalSkills", "softSkills", "education", "keywords", "languages", "seniority"]),
  label: z.string(),
  score: z.number(),
  rationale: z.string(),
});
export const MatchResultSchema = z.object({
  score: z.number(),
  label: z.string(),
  categories: z.array(MatchCategorySchema),
  strengths: z.array(z.string()),
  matchedSkills: z.array(z.string()),
  gaps: z.array(
    z.object({
      item: z.string(),
      severity: z.enum(["high", "medium", "low"]),
      kind: z.enum(["found", "inference", "recommendation"]),
      note: z.string(),
    }),
  ),
  highlightSuggestions: z.array(z.object({ title: z.string(), detail: z.string() })),
  disclaimer: z.string(),
});
export type MatchResult = z.infer<typeof MatchResultSchema>;

export const ResumeContentSchema = z.object({
  fullName: z.string(),
  headline: z.string(),
  contact: z.object({
    city: z.string().nullable(),
    email: z.string().nullable(),
    phone: z.string().nullable(),
    linkedin: z.string().nullable(),
    github: z.string().nullable(),
    portfolio: z.string().nullable(),
  }),
  summary: z.string(),
  experiences: z.array(
    z.object({
      company: z.string(),
      role: z.string(),
      period: z.string(),
      bullets: z.array(z.string()),
    }),
  ),
  education: z.array(z.object({ institution: z.string(), course: z.string(), degree: z.string().nullable(), period: z.string() })),
  skills: z.array(z.string()),
  certifications: z.array(z.string()),
  languages: z.array(z.string()),
});
export type ResumeContent = z.infer<typeof ResumeContentSchema>;

export const OptimizedResumeSchema = z.object({
  resume: ResumeContentSchema,
  changes: z.array(z.string()),
  notIdentified: z.array(z.string()),
});
export type OptimizedResume = z.infer<typeof OptimizedResumeSchema>;

export const ATSResultSchema = z.object({
  score: z.number(),
  categories: z.array(
    z.object({
      key: z.enum(["structure", "keywords", "readability", "experience", "skills", "formatting"]),
      label: z.string(),
      score: z.number(),
    }),
  ),
  issues: z.array(z.object({ type: z.enum(["ok", "warning"]), message: z.string(), fix: z.string().nullable() })),
  missingKeywords: z.array(z.string()),
});
export type ATSResult = z.infer<typeof ATSResultSchema>;

export const InsightsSchema = z.object({
  topSkills: z.array(z.string()),
  marketSkills: z.array(z.object({ skill: z.string(), status: z.enum(["has", "partial", "missing"]), frequency: z.number() })),
  recommendations: z.array(z.object({ title: z.string(), detail: z.string() })),
  summary: z.string(),
});
export type Insights = z.infer<typeof InsightsSchema>;

/** Snapshot of the user's profile sent to the AI (owned by the user; never shared). */
export const ProfileSnapshotSchema = z.object({
  fullName: z.string().nullable(),
  email: z.string().nullable(),
  phone: z.string().nullable(),
  city: z.string().nullable(),
  linkedin: z.string().nullable(),
  github: z.string().nullable(),
  portfolio: z.string().nullable(),
  headline: z.string().nullable(),
  summary: z.string().nullable(),
  targetRole: z.string().nullable(),
  seniority: z.string().nullable(),
  experiences: z.array(ParsedExperienceSchema),
  education: z.array(ParsedEducationSchema),
  skills: z.array(
    z.object({
      name: z.string(),
      category: z.string(),
      level: z
        .string()
        .nullish()
        .transform((v) => v ?? null),
    }),
  ),
});
export type ProfileSnapshot = z.infer<typeof ProfileSnapshotSchema>;

export function matchLabel(score: number) {
  if (score >= 85) return "Excelente compatibilidade";
  if (score >= 70) return "Boa compatibilidade";
  if (score >= 50) return "Compatibilidade parcial";
  return "Baixa compatibilidade";
}
