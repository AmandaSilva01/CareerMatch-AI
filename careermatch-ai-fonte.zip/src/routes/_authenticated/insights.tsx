import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BarChart3, Sparkles, Check, AlertTriangle, Minus, Lightbulb } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { generateInsights } from "@/lib/ai/ai.functions";
import type { Insights } from "@/lib/ai/schemas";
import { jobsQuery, toProfileSnapshot, useProfileBundle } from "@/lib/data/queries";
import { PageHeader, EmptyState, ErrorNotice, AIBadge } from "@/components/career/Primitives";
import { AIProcessing } from "@/components/career/AIProcessing";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/insights")({
  head: () => ({ meta: [{ title: `Insights · ${BRAND.name}` }] }),
  component: InsightsPage,
});

const STEPS = ["Mapeando suas competências...", "Consolidando requisitos das vagas analisadas...", "Comparando você × mercado...", "Gerando recomendações..."];
const STORAGE_KEY = "careermatch.insights.v1";

function InsightsPage() {
  const bundle = useProfileBundle();
  const jobs = useQuery(jobsQuery);
  const gen = useServerFn(generateInsights);
  const [result, setResult] = useState<Insights | null>(() => {
    if (typeof window === "undefined") return null;
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null"); } catch { return null; }
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const parsedJobs = useMemo(() => (jobs.data ?? []).map((j) => j.parsed_data).filter((p): p is NonNullable<typeof p> => !!p), [jobs.data]);

  // Deterministic local stats (no AI) — always available.
  const local = useMemo(() => {
    const freq = new Map<string, number>();
    parsedJobs.forEach((p) => new Set([...p.technicalSkills, ...p.requiredSkills].map((s) => s.toLowerCase())).forEach((s) => freq.set(s, (freq.get(s) ?? 0) + 1)));
    const mine = new Set(bundle.skills.map((s) => s.name.toLowerCase()));
    return [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([skill, n]) => ({ skill, n, has: mine.has(skill) }));
  }, [parsedJobs, bundle.skills]);

  async function run() {
    setBusy(true); setError(null);
    try {
      const r = await gen({ data: { profile: toProfileSnapshot(bundle), jobs: parsedJobs } });
      setResult(r);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(r));
    } catch (e) { setError(e instanceof Error ? e.message : "Não conseguimos gerar os insights agora."); }
    finally { setBusy(false); }
  }

  const ready = parsedJobs.length > 0 && bundle.skills.length > 0;

  return (
    <>
      <PageHeader title="Insights de carreira" description="O que você tem, o que o mercado pede e onde investir." actions={<Button variant="ai" onClick={run} disabled={!ready || busy}><Sparkles /> {result ? "Atualizar insights" : "Gerar insights"}</Button>} />
      {error && <div className="mb-6"><ErrorNotice message={error} onRetry={() => setError(null)} /></div>}
      {busy && <div className="mb-6"><AIProcessing steps={STEPS} active title="Analisando seu posicionamento" /></div>}

      {!ready && !jobs.isLoading && (
        <EmptyState icon={BarChart3} title="Ainda não há dados suficientes" description="Analise algumas vagas e cadastre suas competências para comparar seu perfil com o mercado." actions={<><Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Analisar vaga</Link></Button><Button asChild variant="outline"><Link to="/perfil">Completar perfil</Link></Button></>} />
      )}

      {ready && (
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="surface p-6">
            <h3 className="mb-1 font-semibold">Você possui × Mercado exige</h3>
            <p className="mb-4 text-xs text-muted-foreground">Competências mais pedidas nas {parsedJobs.length} vagas que você analisou.</p>
            <ul className="space-y-2">
              {local.map((s) => (
                <li key={s.skill} className="flex items-center gap-3 text-sm">
                  {s.has ? <Check className="size-4 text-success" /> : <AlertTriangle className="size-4 text-warning" />}
                  <span className="flex-1 capitalize">{s.skill}</span>
                  <div className="h-1.5 w-28 overflow-hidden rounded-full bg-muted"><div className={cn("h-full rounded-full", s.has ? "bg-success" : "bg-warning")} style={{ width: `${(s.n / parsedJobs.length) * 100}%` }} /></div>
                  <span className="w-14 text-right text-xs text-muted-foreground tabular-nums">{s.n}/{parsedJobs.length} vagas</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="surface p-6">
            <h3 className="mb-1 font-semibold">Suas competências mais recorrentes</h3>
            <p className="mb-4 text-xs text-muted-foreground">Cadastradas no seu perfil.</p>
            <div className="flex flex-wrap gap-1.5">
              {(result?.topSkills ?? bundle.skills.filter((s) => s.category === "technical" || s.category === "tool").map((s) => s.name)).slice(0, 20).map((s) => <Badge key={s} variant="soft">{s}</Badge>)}
            </div>
          </section>

          {result && (
            <>
              <section className="surface p-6 lg:col-span-2">
                <div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">Leitura da IA</h3><AIBadge /></div>
                <p className="text-sm leading-relaxed">{result.summary}</p>
                <div className="mt-4 grid gap-2 sm:grid-cols-3">
                  {result.marketSkills.slice(0, 9).map((m) => (
                    <div key={m.skill} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm">
                      {m.status === "has" ? <Check className="size-4 text-success" /> : m.status === "partial" ? <Minus className="size-4 text-warning" /> : <AlertTriangle className="size-4 text-brand" />}
                      <span className="flex-1 truncate">{m.skill}</span><span className="text-xs text-muted-foreground">{m.frequency}×</span>
                    </div>
                  ))}
                </div>
              </section>
              <section className="surface p-6 lg:col-span-2">
                <h3 className="mb-3 font-semibold">Recomendações</h3>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {result.recommendations.map((r, i) => <li key={i} className="flex gap-3 rounded-lg bg-accent p-4 text-sm"><Lightbulb className="mt-0.5 size-4 shrink-0 text-primary" /><div><div className="font-medium">{r.title}</div><div className="text-muted-foreground">{r.detail}</div></div></li>)}
                </ul>
              </section>
            </>
          )}
        </div>
      )}
    </>
  );
}
