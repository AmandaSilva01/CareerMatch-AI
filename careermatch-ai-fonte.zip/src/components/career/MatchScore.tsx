import { cn } from "@/lib/utils";
import { matchLabel } from "@/lib/ai/schemas";

interface MatchRingProps {
  score: number;
  size?: number;
  stroke?: number;
  className?: string;
  showLabel?: boolean;
  animate?: boolean;
}

/** Circular progress ring used for Match Score and ATS Score. */
export function MatchRing({ score, size = 140, stroke = 10, className, showLabel = true, animate = true }: MatchRingProps) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.max(0, Math.min(100, score)) / 100) * c;
  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--color-primary-soft)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--color-primary)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className={animate ? "animate-ring" : undefined}
          style={{ ["--ring-circumference" as string]: c }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-semibold tracking-tight text-foreground" style={{ fontSize: size * 0.26 }}>
          {Math.round(score)}%
        </span>
        {showLabel && size >= 120 && (
          <span className="mt-0.5 px-3 text-center text-[11px] leading-tight text-muted-foreground">{matchLabel(score)}</span>
        )}
      </div>
    </div>
  );
}

export function ScoreBar({ label, score, hint }: { label: string; score: number; hint?: string }) {
  return (
    <div className="space-y-1.5" title={hint}>
      <div className="flex items-center justify-between text-sm">
        <span className="text-foreground">{label}</span>
        <span className="font-medium tabular-nums text-muted-foreground">{Math.round(score)}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-primary-soft">
        <div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${Math.max(0, Math.min(100, score))}%` }} />
      </div>
    </div>
  );
}

export function MatchPill({ score, className }: { score: number; className?: string }) {
  const tone = score >= 85 ? "bg-success-soft text-success" : score >= 70 ? "bg-primary-soft text-accent-foreground" : score >= 50 ? "bg-warning-soft text-warning-foreground" : "bg-muted text-muted-foreground";
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold tabular-nums", tone, className)}>
      {Math.round(score)}% match
    </span>
  );
}
