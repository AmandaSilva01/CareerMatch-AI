import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, AlertTriangle, Sparkles, FileText, Target, ShieldCheck, Play } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { Logo } from "@/components/career/Logo";
import { MatchRing, ScoreBar } from "@/components/career/MatchScore";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const TITLE = `${BRAND.name} — Seu próximo emprego começa com um match inteligente`;
const DESC = "A IA entende a vaga, entende você e conecta os dois: Match Score explicado, gaps identificados e currículos otimizados para ATS sem inventar informações.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const STEPS = [
  { n: "01", title: "Crie seu perfil", desc: "Importe seu currículo em PDF ou DOCX. A IA extrai experiências, formação e competências — você confirma antes de salvar." },
  { n: "02", title: "Encontre uma vaga", desc: "Cole a descrição, envie um arquivo ou escolha uma vaga dentro da plataforma. A IA estrutura requisitos, palavras-chave e senioridade." },
  { n: "03", title: "Receba seu Match", desc: "Compatibilidade estimada por categoria, com explicação do que combina e do que está faltando. Nunca um número solto." },
  { n: "04", title: "Personalize seu currículo", desc: "Uma versão específica para a vaga, otimizada para ATS, sem nenhuma informação inventada. Edite e exporte em PDF ou DOCX." },
];

const PILLARS = [
  { icon: Target, title: "Match explicado", desc: "Experiência, competências, formação, palavras-chave e idiomas — cada fator com ✓ ou ⚠." },
  { icon: FileText, title: "Currículo ATS por vaga", desc: "Texto limpo, estrutura padrão e palavras-chave verdadeiras. Múltiplas versões, um perfil." },
  { icon: ShieldCheck, title: "Zero invenção", desc: "A IA reorganiza e destaca o que você já fez. O que não existe no perfil aparece como 'não identificado'." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Logo />
          <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#como-funciona" className="hover:text-foreground">Como funciona</a>
            <a href="#pilares" className="hover:text-foreground">Por que funciona</a>
            <Link to="/privacidade" className="hover:text-foreground">Privacidade</Link>
          </nav>
          <div className="flex items-center gap-2">
            <Button asChild size="sm"><Link to="/dashboard">Abrir aplicação</Link></Button>
          </div>
        </div>
      </header>

      <section className="bg-hero-glow">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 lg:grid-cols-[1.05fr_1fr] lg:py-28">
          <div className="animate-fade-up">
            <Badge variant="soft" className="mb-5"><Sparkles className="size-3" /> IA que entende vaga e candidato</Badge>
            <h1 className="text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl">Seu próximo emprego começa com um <span className="text-gradient-primary">match inteligente.</span></h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">Nossa IA conecta seu perfil às vagas certas e cria currículos personalizados para cada oportunidade — com explicação transparente e sem inventar nada.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="xl"><Link to="/dashboard">Começar agora <ArrowRight /></Link></Button>
              <Button asChild size="xl" variant="outline"><a href="#como-funciona"><Play /> Ver como funciona</a></Button>
            </div>
            <p className="mt-4 text-xs text-subtle">Sem cadastro · Sem cartão · Seus dados ficam no seu navegador</p>
          </div>

          <ProductMock />
        </div>
      </section>

      <section id="como-funciona" className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-12 max-w-xl">
          <h2 className="text-3xl font-semibold tracking-tight">Como funciona</h2>
          <p className="mt-2 text-muted-foreground">Da vaga ao currículo pronto em quatro passos, sempre com o próximo passo claro.</p>
        </div>
        <ol className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s) => (
            <li key={s.n} className="surface p-6">
              <span className="text-sm font-semibold text-primary">{s.n}</span>
              <h3 className="mt-3 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="pilares" className="border-y bg-muted/40">
        <div className="mx-auto grid max-w-6xl gap-8 px-6 py-20 md:grid-cols-3">
          {PILLARS.map((p) => (
            <div key={p.title}>
              <div className="flex size-10 items-center justify-center rounded-xl bg-primary-soft text-primary"><p.icon className="size-5" /></div>
              <h3 className="mt-4 text-lg font-semibold">{p.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{p.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="text-3xl font-semibold tracking-tight">Pronto para o seu primeiro match?</h2>
        <p className="mx-auto mt-2 max-w-md text-muted-foreground">Crie seu perfil em minutos e descubra o quanto você combina com a vaga que está de olho.</p>
        <Button asChild size="xl" className="mt-8"><Link to="/dashboard">Começar agora <ArrowRight /></Link></Button>
      </section>

      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-muted-foreground sm:flex-row">
          <Logo />
          <div className="flex gap-6"><Link to="/privacidade" className="hover:text-foreground">Privacidade e Segurança</Link><Link to="/dashboard" className="hover:text-foreground">Abrir aplicação</Link></div>
          <span>© {new Date().getFullYear()} {BRAND.name}</span>
        </div>
      </footer>
    </div>
  );
}

function ProductMock() {
  return (
    <div className="surface animate-fade-up p-6 shadow-glow [animation-delay:150ms]" aria-hidden>
      <div className="flex items-center justify-between">
        <div><div className="text-xs text-muted-foreground">Analista de Dados Sênior · Nubank</div><div className="font-semibold">Compatibilidade com seu perfil</div></div>
        <Badge variant="success">Excelente</Badge>
      </div>
      <div className="mt-5 flex items-center gap-6">
        <MatchRing score={92} size={112} />
        <div className="flex-1 space-y-2.5">
          <ScoreBar label="Experiência" score={95} />
          <ScoreBar label="Competências" score={90} />
          <ScoreBar label="Formação" score={100} />
          <ScoreBar label="Palavras-chave" score={84} />
        </div>
      </div>
      <ul className="mt-5 grid gap-1.5 text-sm sm:grid-cols-2">
        {["Experiência compatível", "Competências solicitadas", "Formação adequada", "Palavras-chave relevantes"].map((t) => <li key={t} className="flex items-center gap-2"><Check className="size-4 text-success" /> {t}</li>)}
      </ul>
      <div className="mt-4 flex items-center justify-between rounded-lg bg-warning-soft px-3 py-2 text-sm">
        <span className="flex items-center gap-2"><AlertTriangle className="size-4 text-warning" /> 3 pontos para melhorar</span>
        <span className="text-xs text-muted-foreground">dbt · Airflow · Inglês fluente</span>
      </div>
      <Button className="mt-4 w-full" variant="ai" tabIndex={-1}><Sparkles /> Otimizar currículo</Button>
    </div>
  );
}
