export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      applications: {
        Row: {
          applied_at: string | null
          company: string
          created_at: string
          id: string
          job_id: string | null
          match_score: number | null
          notes: string | null
          resume_id: string | null
          role: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          applied_at?: string | null
          company: string
          created_at?: string
          id?: string
          job_id?: string | null
          match_score?: number | null
          notes?: string | null
          resume_id?: string | null
          role: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          applied_at?: string | null
          company?: string
          created_at?: string
          id?: string
          job_id?: string | null
          match_score?: number | null
          notes?: string | null
          resume_id?: string | null
          role?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "applications_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "applications_resume_id_fkey"
            columns: ["resume_id"]
            isOneToOne: false
            referencedRelation: "resumes"
            referencedColumns: ["id"]
          },
        ]
      }
      education: {
        Row: {
          course: string
          created_at: string
          degree: string | null
          end_date: string | null
          id: string
          institution: string
          start_date: string | null
          user_id: string
        }
        Insert: {
          course: string
          created_at?: string
          degree?: string | null
          end_date?: string | null
          id?: string
          institution: string
          start_date?: string | null
          user_id: string
        }
        Update: {
          course?: string
          created_at?: string
          degree?: string | null
          end_date?: string | null
          id?: string
          institution?: string
          start_date?: string | null
          user_id?: string
        }
        Relationships: []
      }
      experiences: {
        Row: {
          achievements: string[]
          company: string
          created_at: string
          description: string | null
          end_date: string | null
          id: string
          is_current: boolean
          role: string
          sort_order: number
          start_date: string | null
          user_id: string
        }
        Insert: {
          achievements?: string[]
          company: string
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          is_current?: boolean
          role: string
          sort_order?: number
          start_date?: string | null
          user_id: string
        }
        Update: {
          achievements?: string[]
          company?: string
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          is_current?: boolean
          role?: string
          sort_order?: number
          start_date?: string | null
          user_id?: string
        }
        Relationships: []
      }
      jobs: {
        Row: {
          company: string | null
          created_at: string
          description: string
          id: string
          location: string | null
          parsed_data: Json | null
          salary_range: string | null
          seniority: string | null
          source_url: string | null
          title: string
          user_id: string
          work_model: string | null
        }
        Insert: {
          company?: string | null
          created_at?: string
          description: string
          id?: string
          location?: string | null
          parsed_data?: Json | null
          salary_range?: string | null
          seniority?: string | null
          source_url?: string | null
          title: string
          user_id: string
          work_model?: string | null
        }
        Update: {
          company?: string | null
          created_at?: string
          description?: string
          id?: string
          location?: string | null
          parsed_data?: Json | null
          salary_range?: string | null
          seniority?: string | null
          source_url?: string | null
          title?: string
          user_id?: string
          work_model?: string | null
        }
        Relationships: []
      }
      matches: {
        Row: {
          analysis: Json
          breakdown: Json
          created_at: string
          id: string
          job_id: string
          score: number
          user_id: string
        }
        Insert: {
          analysis?: Json
          breakdown?: Json
          created_at?: string
          id?: string
          job_id: string
          score: number
          user_id: string
        }
        Update: {
          analysis?: Json
          breakdown?: Json
          created_at?: string
          id?: string
          job_id?: string
          score?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "matches_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          ai_consent: boolean
          city: string | null
          created_at: string
          email: string | null
          full_name: string | null
          github: string | null
          headline: string | null
          id: string
          interest_areas: string[]
          linkedin: string | null
          onboarding_completed: boolean
          phone: string | null
          plan: string
          portfolio: string | null
          seniority: string | null
          summary: string | null
          target_locations: string[]
          target_role: string | null
          updated_at: string
          user_id: string
          work_model: string | null
        }
        Insert: {
          ai_consent?: boolean
          city?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          github?: string | null
          headline?: string | null
          id?: string
          interest_areas?: string[]
          linkedin?: string | null
          onboarding_completed?: boolean
          phone?: string | null
          plan?: string
          portfolio?: string | null
          seniority?: string | null
          summary?: string | null
          target_locations?: string[]
          target_role?: string | null
          updated_at?: string
          user_id: string
          work_model?: string | null
        }
        Update: {
          ai_consent?: boolean
          city?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          github?: string | null
          headline?: string | null
          id?: string
          interest_areas?: string[]
          linkedin?: string | null
          onboarding_completed?: boolean
          phone?: string | null
          plan?: string
          portfolio?: string | null
          seniority?: string | null
          summary?: string | null
          target_locations?: string[]
          target_role?: string | null
          updated_at?: string
          user_id?: string
          work_model?: string | null
        }
        Relationships: []
      }
      resumes: {
        Row: {
          ats_analysis: Json | null
          ats_score: number | null
          base_resume_id: string | null
          content: Json
          created_at: string
          id: string
          is_base: boolean
          job_id: string | null
          match_score: number | null
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ats_analysis?: Json | null
          ats_score?: number | null
          base_resume_id?: string | null
          content?: Json
          created_at?: string
          id?: string
          is_base?: boolean
          job_id?: string | null
          match_score?: number | null
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ats_analysis?: Json | null
          ats_score?: number | null
          base_resume_id?: string | null
          content?: Json
          created_at?: string
          id?: string
          is_base?: boolean
          job_id?: string | null
          match_score?: number | null
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "resumes_base_resume_id_fkey"
            columns: ["base_resume_id"]
            isOneToOne: false
            referencedRelation: "resumes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resumes_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      skills: {
        Row: {
          category: string
          created_at: string
          id: string
          level: string | null
          name: string
          user_id: string
        }
        Insert: {
          category?: string
          created_at?: string
          id?: string
          level?: string | null
          name: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          level?: string | null
          name?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
