import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { Sparkles, FileText, Check } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { optimizeResume } from "@/lib/ai/ai.functions";
import { jobsQuery, matchesQuery, resumesQuery, snapshotToResume, toProfileSnapshot, useInsert, useProfileBundle } from "@/lib/data/queries";
import { PageHeader, ErrorNotice, NextStep, AIBadge } from "@/components/career/Primitives";
import { AIProcessing, RESUME_STEPS } from "@/components/career/AIProcessing";
import { MatchPill } from "@/components/career/MatchScore";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export const Route = createFileRoute("/_authenticated/curriculos/novo")({
  validateSearch: z.object({ matchId: z.string().optional() }),
  head: () => ({ meta: [{ title: `Gerar currículo · ${BRAND.name}` }] }),
  component: NewResume,
});

const NONE = "none";

function NewResume() {
  const { matchId } = Route.useSearch();
  const navigate = useNavigate();
  const bundle = useProfileBundle();
  const matches = useQuery(matchesQuery);
  const jobs = useQuery(jobsQuery);
  const resumes = useQuery(resumesQuery);
  const insert = useInsert("resumes");
  const optimize = useServerFn(optimizeResume);

  const [selMatch, setSelMatch] = useState<string>(matchId ?? NONE);
  const [baseId, setBaseId] = useState<string>(NONE);
  const [mode, setMode] = useState<"ai" | "base">("ai");
  const [name, setName] = useState("");
  const [instruction, setInstruction] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (matchId) setSelMatch(matchId);
  }, [matchId]);

  const match = matches.data?.find((m) => m.id === selMatch);
  const job = match ? jobs.data?.find((j) => j.id === match.job_id) : undefined;
  const base = resumes.data?.find((r) => r.id === baseId);
  const profileReady = !bundle.loading && (bundle.experiences.length > 0 || bundle.skills.length > 0 || !!bundle.profile?.summary);
  const suggestedName = job ? `${job.title}${job.company ? ` · ${job.company}` : ""}` : "Currículo base";

  async function generate() {
    setBusy(true);
    setError(null);
    try {
      const snapshot = toProfileSnapshot(bundle);
      const baseContent = base?.content ?? snapshotToResume(snapshot);
      let content = baseContent;
      let notIdentified: string[] = [];
      if (mode === "ai") {
        const out = await optimize({ data: { profile: snapshot, job: job?.parsed_data ?? null, match: match?.analysis ?? null, baseResume: baseContent, instruction: instruction || null } });
        content = out.resume;
        notIdentified = out.notIdentified;
      }
      const row = await insert.mutateAsync({
        name: name.trim() || suggestedName,
        is_base: !job,
        base_resume_id: base?.id ?? null,
        job_id: job?.id ?? null,
        content,
        match_score: match?.score ?? null,
      } as never);
      toast.success(mode === "ai" ? "Currículo gerado. Revise e analise no ATS." : "Currículo criado a partir do seu perfil.");
      if (notIdentified.length) toast.info(`Não identificado no perfil: ${notIdentified.slice(0, 3).join(", ")}${notIdentified.length > 3 ? "…" : ""}`);
      navigate({ to: "/curriculos/$resumeId", params: { resumeId: row.id } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não conseguimos gerar o currículo agora. Suas informações foram preservadas.");
    } finally {
      setBusy(false);
    }
  }

  if (busy && mode === "ai") return <AIProcessing steps={RESUME_STEPS} active title="Gerando seu currículo personalizado" />;

  return (
    <>
      <PageHeader eyebrow="Passo 3 de 3 · Currículo" title="Gerar currículo" description="Escolha a vaga-alvo e o ponto de partida. A IA adapta o que você já tem — nunca inventa." />
      {!profileReady && <div className="mb-6"><NextStep title="Seu perfil está vazio" description="Importe um currículo ou preencha experiências para gerar um currículo real." to="/perfil" cta="Completar perfil" /></div>}
      {error && <div className="mb-6"><ErrorNotice message={error} onRetry={() => setError(null)} /></div>}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="surface space-y-6 p-6 lg:col-span-2">
          <div className="space-y-1.5">
            <Label>Vaga-alvo</Label>
            <Select value={selMatch} onValueChange={setSelMatch}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>Sem vaga específica (currículo base)</SelectItem>
                {(matches.data ?? []).map((m) => {
                  const j = jobs.data?.find((x) => x.id === m.job_id);
                  return <SelectItem key={m.id} value={m.id}>{j?.title ?? "Vaga"}{j?.company ? ` · ${j.company}` : ""} — {m.score}%</SelectItem>;
                })}
              </SelectContent>
            </Select>
            {(matches.data ?? []).length === 0 && <p className="text-xs text-muted-foreground">Nenhuma vaga analisada. <Link to="/match/nova" className="text-primary hover:underline">Analisar uma vaga</Link> para gerar uma versão personalizada.</p>}
          </div>

          <div className="space-y-1.5">
            <Label>Ponto de partida</Label>
            <Select value={baseId} onValueChange={setBaseId}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>Meu perfil (experiências e competências cadastradas)</SelectItem>
                {(resumes.data ?? []).map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Como criar</Label>
            <RadioGroup value={mode} onValueChange={(v) => setMode(v as "ai" | "base")} className="grid gap-2 sm:grid-cols-2">
              <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-colors ${mode === "ai" ? "border-primary bg-primary-soft/50" : "hover:bg-accent"}`}>
                <RadioGroupItem value="ai" className="mt-0.5" />
                <div><div className="flex items-center gap-2 text-sm font-medium">Otimizar com IA <AIBadge /></div><p className="text-xs text-muted-foreground">Reorganiza, destaca e adapta ao contexto da vaga, com palavras-chave verdadeiras.</p></div>
              </label>
              <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-colors ${mode === "base" ? "border-primary bg-primary-soft/50" : "hover:bg-accent"}`}>
                <RadioGroupItem value="base" className="mt-0.5" />
                <div><div className="text-sm font-medium">Copiar sem alterações</div><p className="text-xs text-muted-foreground">Cria a versão a partir do ponto de partida para você editar manualmente.</p></div>
              </label>
            </RadioGroup>
          </div>

          <div className="space-y-1.5"><Label>Nome da versão</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder={suggestedName} /></div>
          {mode === "ai" && <div className="space-y-1.5"><Label>Instrução adicional (opcional)</Label><Textarea rows={2} value={instruction} onChange={(e) => setInstruction(e.target.value)} placeholder="Ex.: dê mais peso à experiência com dashboards; mantenha o resumo em 3 linhas." /></div>}

          <div className="flex justify-end">
            <Button size="lg" variant={mode === "ai" ? "ai" : "default"} onClick={generate} disabled={busy || !profileReady}>
              {mode === "ai" ? <><Sparkles /> Gerar currículo</> : <><FileText /> Criar versão</>}
            </Button>
          </div>
        </div>

        <aside className="space-y-4">
          {match && job ? (
            <div className="surface p-5">
              <div className="flex items-center justify-between"><span className="text-sm font-medium">Vaga-alvo</span><MatchPill score={match.score} /></div>
              <div className="mt-2 font-semibold">{job.title}</div>
              <div className="text-sm text-muted-foreground">{job.company}</div>
              <ul className="mt-3 space-y-1.5 text-sm">
                {match.analysis.highlightSuggestions.slice(0, 3).map((h, i) => <li key={i} className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-primary" />{h.title}</li>)}
              </ul>
              <p className="mt-3 text-xs text-subtle">A IA vai enfatizar esses pontos ao gerar.</p>
            </div>
          ) : (
            <div className="surface p-5 text-sm text-muted-foreground">Sem vaga selecionada, a IA cria um currículo base forte a partir do seu perfil.</div>
          )}
          <div className="rounded-xl border border-brand/20 bg-brand-soft p-4 text-xs leading-relaxed text-foreground">
            <span className="font-semibold text-brand">Compromisso de factualidade.</span> Nada é inventado: experiências, números, cargos e certificações vêm apenas do seu perfil. Requisitos ausentes são listados como “Não identificado no perfil”.
          </div>
        </aside>
      </div>
    </>
  );
}
