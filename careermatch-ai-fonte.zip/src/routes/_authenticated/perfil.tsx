import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Trash2, Upload, Save, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { AREAS, SENIORITIES, SKILL_CATEGORIES, WORK_MODELS } from "@/lib/options";
import { useInsert, useProfileBundle, useRemove, useUpdate, useUpsertProfile, type Experience, type Education } from "@/lib/data/queries";
import { PageHeader } from "@/components/career/Primitives";
import { ResumeImport } from "@/components/career/ResumeImport";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/perfil")({
  validateSearch: z.object({ import: z.coerce.number().optional() }),
  head: () => ({ meta: [{ title: `Meu perfil · ${BRAND.name}` }] }),
  component: ProfilePage,
});

const profileSchema = z.object({
  full_name: z.string().min(2, "Informe seu nome"),
  email: z.string().email("E-mail inválido").or(z.literal("")),
  phone: z.string(),
  city: z.string(),
  linkedin: z.string(),
  github: z.string(),
  portfolio: z.string(),
  headline: z.string(),
  summary: z.string(),
  target_role: z.string(),
  seniority: z.string(),
  work_model: z.string(),
  target_locations: z.string(),
});
type ProfileForm = z.infer<typeof profileSchema>;

function ProfilePage() {
  const search = Route.useSearch();
  const b = useProfileBundle();
  const [importOpen, setImportOpen] = useState(!!search.import);

  return (
    <>
      <PageHeader
        title="Meu perfil"
        description="A base de tudo: quanto mais completo, mais precisos ficam o match e o currículo."
        actions={
          <Dialog open={importOpen} onOpenChange={setImportOpen}>
            <DialogTrigger asChild><Button variant="ai"><Upload /> Importar currículo</Button></DialogTrigger>
            <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
              <DialogHeader><DialogTitle className="flex items-center gap-2"><Sparkles className="size-4 text-primary" /> Importar currículo</DialogTitle></DialogHeader>
              <p className="text-sm text-muted-foreground">A importação substitui experiências, formação e competências atuais pelos dados do arquivo (você confirma antes).</p>
              <ResumeImport onDone={() => setImportOpen(false)} />
            </DialogContent>
          </Dialog>
        }
      />
      {b.loading ? <Skeleton className="h-96 rounded-xl" /> : (
        <Tabs defaultValue="info">
          <TabsList className="mb-6 flex w-full justify-start overflow-x-auto sm:w-auto">
            <TabsTrigger value="info">Informações</TabsTrigger>
            <TabsTrigger value="exp">Experiências ({b.experiences.length})</TabsTrigger>
            <TabsTrigger value="edu">Formação ({b.education.length})</TabsTrigger>
            <TabsTrigger value="skills">Competências ({b.skills.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="info"><InfoTab /></TabsContent>
          <TabsContent value="exp"><ExperiencesTab items={b.experiences} /></TabsContent>
          <TabsContent value="edu"><EducationTab items={b.education} /></TabsContent>
          <TabsContent value="skills"><SkillsTab /></TabsContent>
        </Tabs>
      )}
    </>
  );
}

function InfoTab() {
  const { profile } = useProfileBundle();
  const upsert = useUpsertProfile();
  const [areas, setAreas] = useState<string[]>(profile?.interest_areas ?? []);
  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      full_name: profile?.full_name ?? "", email: profile?.email ?? "", phone: profile?.phone ?? "", city: profile?.city ?? "", linkedin: profile?.linkedin ?? "", github: profile?.github ?? "",
      portfolio: profile?.portfolio ?? "", headline: profile?.headline ?? "", summary: profile?.summary ?? "", target_role: profile?.target_role ?? "", seniority: profile?.seniority ?? "",
      work_model: profile?.work_model ?? "", target_locations: (profile?.target_locations ?? []).join(", "),
    },
  });
  useEffect(() => { if (profile) setAreas(profile.interest_areas ?? []); }, [profile]);
  const onSubmit = form.handleSubmit(async (v) => {
    const clean = Object.fromEntries(Object.entries(v).map(([k, val]) => [k, val === "" ? null : val]));
    await upsert.mutateAsync({ ...clean, target_locations: v.target_locations.split(",").map((s) => s.trim()).filter(Boolean), interest_areas: areas } as never);
    toast.success("Perfil salvo.");
  });
  const err = form.formState.errors;
  const F = ({ name, label, textarea }: { name: keyof ProfileForm; label: string; textarea?: boolean }) => (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {textarea ? <Textarea rows={4} {...form.register(name)} /> : <Input {...form.register(name)} />}
      {err[name] && <p className="text-xs text-destructive">{err[name]?.message}</p>}
    </div>
  );
  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <section className="surface space-y-4 p-6">
        <h3 className="font-semibold">Informações pessoais</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <F name="full_name" label="Nome completo" /><F name="email" label="E-mail" /><F name="phone" label="Telefone" /><F name="city" label="Cidade" />
          <F name="linkedin" label="LinkedIn" /><F name="github" label="GitHub" /><F name="portfolio" label="Portfólio" /><F name="headline" label="Título profissional" />
        </div>
        <F name="summary" label="Resumo profissional" textarea />
      </section>
      <section className="surface space-y-4 p-6">
        <h3 className="font-semibold">Objetivo</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <F name="target_role" label="Cargo desejado" />
          <div className="space-y-1.5"><Label>Senioridade</Label>
            <Select value={form.watch("seniority")} onValueChange={(v) => form.setValue("seniority", v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{SENIORITIES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="space-y-1.5"><Label>Modelo de trabalho</Label>
            <Select value={form.watch("work_model")} onValueChange={(v) => form.setValue("work_model", v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{WORK_MODELS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
          </div>
          <F name="target_locations" label="Localizações de interesse (vírgula)" />
        </div>
        <div className="space-y-2"><Label>Áreas de interesse</Label>
          <div className="flex flex-wrap gap-2">
            {AREAS.map((a) => (
              <label key={a} className="flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-1.5 text-sm has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary-soft">
                <Checkbox checked={areas.includes(a)} onCheckedChange={(c) => setAreas((s) => (c ? [...s, a] : s.filter((x) => x !== a)))} /> {a}
              </label>
            ))}
          </div>
        </div>
      </section>
      <div className="flex justify-end"><Button type="submit" disabled={upsert.isPending}><Save /> Salvar perfil</Button></div>
    </form>
  );
}

function ExperiencesTab({ items }: { items: Experience[] }) {
  const insert = useInsert("experiences");
  const update = useUpdate("experiences");
  const remove = useRemove("experiences");
  const [editing, setEditing] = useState<Partial<Experience> | null>(null);
  const save = async () => {
    if (!editing?.company || !editing.role) { toast.error("Empresa e cargo são obrigatórios."); return; }
    const patch = { company: editing.company, role: editing.role, start_date: editing.start_date ?? null, end_date: editing.is_current ? null : (editing.end_date ?? null), is_current: !!editing.is_current, description: editing.description ?? null, achievements: editing.achievements ?? [] };
    if (editing.id) await update.mutateAsync({ id: editing.id, patch });
    else await insert.mutateAsync(patch as never);
    setEditing(null);
  };
  return (
    <div className="space-y-4">
      <div className="flex justify-end"><Button onClick={() => setEditing({ is_current: false, achievements: [] })}><Plus /> Adicionar experiência</Button></div>
      {items.length === 0 && <p className="surface p-6 text-center text-sm text-muted-foreground">Nenhuma experiência cadastrada. Importe um currículo ou adicione manualmente.</p>}
      {items.map((e) => (
        <div key={e.id} className="surface flex items-start justify-between gap-4 p-5">
          <div className="min-w-0">
            <div className="font-semibold">{e.role}</div>
            <div className="text-sm text-muted-foreground">{e.company} · {[e.start_date, e.is_current ? "Atual" : e.end_date].filter(Boolean).join(" – ") || "Período não informado"}</div>
            {e.description && <p className="mt-2 text-sm">{e.description}</p>}
            {e.achievements.length > 0 && <ul className="mt-2 list-disc space-y-0.5 pl-5 text-sm text-muted-foreground">{e.achievements.map((a, i) => <li key={i}>{a}</li>)}</ul>}
          </div>
          <div className="flex shrink-0 gap-1">
            <Button variant="ghost" size="sm" onClick={() => setEditing(e)}>Editar</Button>
            <Button variant="ghost" size="icon" aria-label="Remover" onClick={() => remove.mutate(e.id)}><Trash2 /></Button>
          </div>
        </div>
      ))}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing?.id ? "Editar experiência" : "Nova experiência"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1"><Label>Empresa</Label><Input value={editing.company ?? ""} onChange={(e) => setEditing({ ...editing, company: e.target.value })} /></div>
              <div className="space-y-1"><Label>Cargo</Label><Input value={editing.role ?? ""} onChange={(e) => setEditing({ ...editing, role: e.target.value })} /></div>
              <div className="space-y-1"><Label>Início</Label><Input placeholder="mar/2021" value={editing.start_date ?? ""} onChange={(e) => setEditing({ ...editing, start_date: e.target.value })} /></div>
              <div className="space-y-1"><Label>Fim</Label><Input placeholder="dez/2023" disabled={!!editing.is_current} value={editing.end_date ?? ""} onChange={(e) => setEditing({ ...editing, end_date: e.target.value })} /></div>
              <label className="flex items-center gap-2 text-sm sm:col-span-2"><Switch checked={!!editing.is_current} onCheckedChange={(c) => setEditing({ ...editing, is_current: c })} /> Trabalho atualmente aqui</label>
              <div className="space-y-1 sm:col-span-2"><Label>Descrição / responsabilidades</Label><Textarea rows={3} value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
              <div className="space-y-1 sm:col-span-2"><Label>Resultados (um por linha)</Label><Textarea rows={3} value={(editing.achievements ?? []).join("\n")} onChange={(e) => setEditing({ ...editing, achievements: e.target.value.split("\n").filter((l) => l.trim()) })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="ghost" onClick={() => setEditing(null)}>Cancelar</Button><Button onClick={save}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EducationTab({ items }: { items: Education[] }) {
  const insert = useInsert("education");
  const update = useUpdate("education");
  const remove = useRemove("education");
  const [editing, setEditing] = useState<Partial<Education> | null>(null);
  const save = async () => {
    if (!editing?.institution || !editing.course) { toast.error("Instituição e curso são obrigatórios."); return; }
    const patch = { institution: editing.institution, course: editing.course, degree: editing.degree ?? null, start_date: editing.start_date ?? null, end_date: editing.end_date ?? null };
    if (editing.id) await update.mutateAsync({ id: editing.id, patch });
    else await insert.mutateAsync(patch as never);
    setEditing(null);
  };
  return (
    <div className="space-y-4">
      <div className="flex justify-end"><Button onClick={() => setEditing({})}><Plus /> Adicionar formação</Button></div>
      {items.length === 0 && <p className="surface p-6 text-center text-sm text-muted-foreground">Nenhuma formação cadastrada.</p>}
      {items.map((e) => (
        <div key={e.id} className="surface flex items-start justify-between gap-4 p-5">
          <div><div className="font-semibold">{[e.degree, e.course].filter(Boolean).join(" em ")}</div><div className="text-sm text-muted-foreground">{e.institution} · {[e.start_date, e.end_date].filter(Boolean).join(" – ") || "Período não informado"}</div></div>
          <div className="flex shrink-0 gap-1"><Button variant="ghost" size="sm" onClick={() => setEditing(e)}>Editar</Button><Button variant="ghost" size="icon" aria-label="Remover" onClick={() => remove.mutate(e.id)}><Trash2 /></Button></div>
        </div>
      ))}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing?.id ? "Editar formação" : "Nova formação"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1 sm:col-span-2"><Label>Instituição</Label><Input value={editing.institution ?? ""} onChange={(e) => setEditing({ ...editing, institution: e.target.value })} /></div>
              <div className="space-y-1"><Label>Curso</Label><Input value={editing.course ?? ""} onChange={(e) => setEditing({ ...editing, course: e.target.value })} /></div>
              <div className="space-y-1"><Label>Grau</Label><Input placeholder="Bacharelado, MBA…" value={editing.degree ?? ""} onChange={(e) => setEditing({ ...editing, degree: e.target.value })} /></div>
              <div className="space-y-1"><Label>Início</Label><Input value={editing.start_date ?? ""} onChange={(e) => setEditing({ ...editing, start_date: e.target.value })} /></div>
              <div className="space-y-1"><Label>Conclusão</Label><Input value={editing.end_date ?? ""} onChange={(e) => setEditing({ ...editing, end_date: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="ghost" onClick={() => setEditing(null)}>Cancelar</Button><Button onClick={save}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SkillsTab() {
  const { skills } = useProfileBundle();
  const insert = useInsert("skills");
  const remove = useRemove("skills");
  const [name, setName] = useState("");
  const [category, setCategory] = useState<string>("technical");
  const [level, setLevel] = useState("");
  const add = async () => {
    if (!name.trim()) return;
    await insert.mutateAsync({ name: name.trim(), category, level: level || null } as never);
    setName(""); setLevel("");
  };
  return (
    <div className="space-y-6">
      <form className="surface flex flex-col gap-3 p-4 sm:flex-row" onSubmit={(e) => { e.preventDefault(); add(); }}>
        <Input placeholder="Ex.: SQL, Power BI, Inglês…" value={name} onChange={(e) => setName(e.target.value)} className="flex-1" />
        <Select value={category} onValueChange={setCategory}><SelectTrigger className="sm:w-44"><SelectValue /></SelectTrigger><SelectContent>{SKILL_CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent></Select>
        {category === "language" && <Input placeholder="Nível (ex.: Avançado)" value={level} onChange={(e) => setLevel(e.target.value)} className="sm:w-40" />}
        <Button type="submit"><Plus /> Adicionar</Button>
      </form>
      {SKILL_CATEGORIES.map((c) => {
        const list = skills.filter((s) => s.category === c.value);
        return (
          <section key={c.value} className="surface p-5">
            <h3 className="mb-3 text-sm font-semibold">{c.label} <span className="text-subtle">({list.length})</span></h3>
            {list.length === 0 ? <p className="text-sm text-subtle">Nenhuma cadastrada.</p> : (
              <div className="flex flex-wrap gap-2">
                {list.map((s) => (
                  <Badge key={s.id} variant="secondary" className="gap-1 pr-1">
                    {s.name}{s.level ? ` · ${s.level}` : ""}
                    <button aria-label={`Remover ${s.name}`} onClick={() => remove.mutate(s.id)} className="rounded-full p-0.5 hover:bg-foreground/10"><Trash2 className="size-3" /></button>
                  </Badge>
                ))}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
