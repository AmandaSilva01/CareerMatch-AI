/**
 * Local browser store — the app runs without accounts, so every record lives in
 * localStorage on the visitor's own device. Same row shapes as the database
 * schema, so the rest of the app is unchanged.
 */
import type { Tables } from "@/integrations/supabase/types";

export type TableName =
  | "profiles"
  | "experiences"
  | "education"
  | "skills"
  | "jobs"
  | "matches"
  | "resumes"
  | "applications";

export type Row<T extends TableName> = Tables<T>;

const KEY = "careermatch.local.v1";
const LOCAL_USER = "local-user";

type DB = { [K in TableName]: Row<K>[] };

const EMPTY: DB = {
  profiles: [],
  experiences: [],
  education: [],
  skills: [],
  jobs: [],
  matches: [],
  resumes: [],
  applications: [],
};

const hasStorage = () => typeof window !== "undefined" && !!window.localStorage;

const listeners = new Set<() => void>();
export function onLocalChange(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function read(): DB {
  if (!hasStorage()) return { ...EMPTY };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return { ...EMPTY };
    return { ...EMPTY, ...(JSON.parse(raw) as Partial<DB>) };
  } catch {
    return { ...EMPTY };
  }
}

function write(db: DB) {
  if (!hasStorage()) return;
  window.localStorage.setItem(KEY, JSON.stringify(db));
  listeners.forEach((fn) => fn());
}

const uid = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2) + Date.now().toString(36);

export const local = {
  list<T extends TableName>(table: T): Row<T>[] {
    return read()[table] as Row<T>[];
  },

  insert<T extends TableName>(table: T, row: Record<string, unknown>): Row<T> {
    const db = read();
    const now = new Date().toISOString();
    const full = {
      id: uid(),
      user_id: LOCAL_USER,
      created_at: now,
      updated_at: now,
      ...row,
    } as unknown as Row<T>;
    (db[table] as Row<T>[]) = [...(db[table] as Row<T>[]), full];
    write(db);
    return full;
  },

  update<T extends TableName>(table: T, id: string, patch: Record<string, unknown>): Row<T> {
    const db = read();
    const rows = db[table] as Array<Row<T> & { id: string }>;
    let updated: Row<T> | null = null;
    (db[table] as Row<T>[]) = rows.map((r) => {
      if (r.id !== id) return r;
      updated = { ...r, ...patch, updated_at: new Date().toISOString() } as Row<T>;
      return updated;
    });
    write(db);
    if (!updated) throw new Error("Registro não encontrado.");
    return updated;
  },

  remove<T extends TableName>(table: T, id: string) {
    const db = read();
    (db[table] as Array<{ id: string }>) = (db[table] as Array<{ id: string }>).filter((r) => r.id !== id);
    write(db);
  },

  /** Replaces every row of a table (used when re-importing a resume). */
  replaceAll<T extends TableName>(table: T, rows: Array<Record<string, unknown>>): Row<T>[] {
    const db = read();
    const now = new Date().toISOString();
    const full = rows.map(
      (row) => ({ id: uid(), user_id: LOCAL_USER, created_at: now, updated_at: now, ...row }) as unknown as Row<T>,
    );
    (db[table] as Row<T>[]) = full;
    write(db);
    return full;
  },

  clear(table: TableName) {
    const db = read();
    (db[table] as unknown[]) = [];
    write(db);
  },

  /** Single profile row (created on first write). */
  profile(): Row<"profiles"> | null {
    return read().profiles[0] ?? null;
  },

  upsertProfile(patch: Record<string, unknown>): Row<"profiles"> {
    const db = read();
    const now = new Date().toISOString();
    const current = db.profiles[0];
    const next = {
      id: current?.id ?? uid(),
      user_id: LOCAL_USER,
      created_at: current?.created_at ?? now,
      ...current,
      ...patch,
      updated_at: now,
    } as unknown as Row<"profiles">;
    db.profiles = [next];
    write(db);
    return next;
  },

  snapshot(): DB {
    return read();
  },

  wipe() {
    if (hasStorage()) window.localStorage.removeItem(KEY);
    listeners.forEach((fn) => fn());
  },
};
