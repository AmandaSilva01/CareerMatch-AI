import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Sparkles, Building2, MapPin, ArrowUpRight, Info } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { AREAS, SENIORITIES, WORK_MODELS } from "@/lib/options";
import { listSuggestedJobs, type SuggestedJob } from "@/lib/mock/jobs";
import { jobsQuery, matchesQuery, useProfile } from "@/lib/data/queries";
import { useAnalyzeJob } from "@/lib/flows/analyze-job";
import { PageHeader, ErrorNotice } from "@/components/career/Primitives";
import { JobCard } from "@/components/career/JobCard";
import { AIProcessing, MATCH_STEPS } from "@/components/career/AIProcessing";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";

export const Route = createFileRoute("/_authenticated/vagas/")({
  head: () => ({ meta: [{ title: `Encontrar vagas · ${BRAND.name}` }] }),
  component: JobDiscovery,
});

const ALL = "all";

function JobDiscovery() {
  const { data: profile } = useProfile();
  const jobs = useQuery(jobsQuery);
  const matches = useQuery(matchesQuery);
  const flow = useAnalyzeJob();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [area, setArea] = useState(ALL);
  const [model, setModel] = useState(ALL);
  const [level, setLevel] = useState(ALL);
  const [minMatch, setMinMatch] = useState(0);

  const suggested = useMemo(() => {
    const areas = profile?.interest_areas ?? [];
    return listSuggestedJobs()
      .filter((j) => (area === ALL || j.area === area) && (model === ALL || j.workModel === model) && (level === ALL || j.seniority === level))
      .filter((j) => !q || `${j.title} ${j.company} ${j.location}`.toLowerCase().includes(q.toLowerCase()))
      .sort((a, b) => Number(areas.includes(b.area)) - Number(areas.includes(a.area)));
  }, [profile, area, model, level, q]);

  const mine = useMemo(() => {
    const ms = matches.data ?? [];
    return (jobs.data ?? [])
      .map((j) => ({ job: j, match: ms.find((m) => m.job_id === j.id) }))
      .filter(({ job, match }) => (minMatch === 0 || (match?.score ?? 0) >= minMatch) && (!q || `${job.title} ${job.company ?? ""}`.toLowerCase().includes(q.toLowerCase())))
      .sort((a, b) => (b.match?.score ?? -1) - (a.match?.score ?? -1));
  }, [jobs.data, matches.data, minMatch, q]);

  async function analyzeSuggested(j: SuggestedJob) {
    const res = await flow.analyze(j.description);
    if (res) navigate({ to: "/match/$matchId", params: { matchId: res.match.id } });
  }

  if (flow.stage === "parsing" || flow.stage === "matching") return <AIProcessing steps={MATCH_STEPS} active title="Analisando a vaga e calculando seu match" />;

  return (
    <>
      <PageHeader
        title="Encontrar vagas"
        description="Explore oportunidades, ordene por compatibilidade com seu perfil e gere um currículo em um clique."
        actions={<Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Colar uma vaga</Link></Button>}
      />
      {flow.stage === "error" && flow.error && <div className="mb-6"><ErrorNotice message={flow.error} onRetry={flow.reset} /></div>}

      <div className="surface mb-6 grid gap-3 p-4 md:grid-cols-5">
        <div className="relative md:col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
          <Input className="pl-9" placeholder="Cargo, empresa ou local" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Filter value={area} onChange={setArea} placeholder="Área" options={AREAS} />
        <Filter value={model} onChange={setModel} placeholder="Modelo" options={WORK_MODELS} />
        <Filter value={level} onChange={setLevel} placeholder="Senioridade" options={SENIORITIES} />
      </div>

      <Tabs defaultValue={mine.length > 0 ? "mine" : "suggested"}>
        <TabsList className="mb-4">
          <TabsTrigger value="mine">Minhas vagas ({jobs.data?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="suggested">Sugestões ({suggested.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="mine" className="space-y-4">
          <div className="flex items-center gap-4 rounded-xl bg-accent px-4 py-3 text-sm">
            <span className="whitespace-nowrap font-medium">Match mínimo: {minMatch}%</span>
            <Slider value={[minMatch]} onValueChange={([v]) => setMinMatch(v ?? 0)} max={100} step={5} className="max-w-xs" />
          </div>
          {mine.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">Nenhuma vaga salva com esses filtros. Analise uma sugestão ou cole uma descrição.</p>}
          <div className="grid gap-4 md:grid-cols-2">{mine.map(({ job, match }) => <JobCard key={job.id} job={job} match={match} />)}</div>
        </TabsContent>

        <TabsContent value="suggested" className="space-y-4">
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><Info className="size-3.5" /> Vagas de exemplo para você testar o fluxo. A integração com portais de emprego será conectada aqui.</p>
          <div className="grid gap-4 md:grid-cols-2">
            {suggested.map((j) => (
              <article key={j.id} className="surface flex flex-col gap-3 p-5 transition-shadow hover:shadow-soft">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate font-semibold">{j.title}</h3>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><Building2 className="size-3" /> {j.company}</span>
                      <span className="inline-flex items-center gap-1"><MapPin className="size-3" /> {j.location} · {j.workModel}</span>
                    </div>
                  </div>
                  {(profile?.interest_areas ?? []).includes(j.area) && <Badge variant="soft">Sua área</Badge>}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Badge variant="secondary">{j.area}</Badge>
                  <Badge variant="outline">{j.seniority}</Badge>
                  {j.salaryRange && <Badge variant="outline">{j.salaryRange}</Badge>}
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-muted-foreground">Analise para ver a compatibilidade</span>
                  <div className="flex gap-1.5">
                    <Button asChild size="sm" variant="ghost"><Link to="/vagas/$jobId" params={{ jobId: j.id }}>Ver vaga <ArrowUpRight /></Link></Button>
                    <Button size="sm" variant="soft" onClick={() => analyzeSuggested(j)}><Sparkles /> Calcular match</Button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
}

function Filter({ value, onChange, placeholder, options }: { value: string; onChange: (v: string) => void; placeholder: string; options: readonly string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full"><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>{placeholder}: todas</SelectItem>
        {options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}
