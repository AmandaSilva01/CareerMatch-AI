import { createFileRoute } from "@tanstack/react-router";
import { Check, Sparkles } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { useProfile } from "@/lib/data/queries";
import { PageHeader } from "@/components/career/Primitives";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/plano")({
  head: () => ({ meta: [{ title: `Plano · ${BRAND.name}` }] }),
  component: PlanPage,
});

/** Plan catalog — single source of truth; Stripe price IDs plug in here later. */
export const PLANS = [
  { id: "free", name: "Free", price: "R$ 0", period: "para sempre", features: ["1 currículo base", "Até 3 matches por mês", "ATS Analyzer básico", "Análises de IA limitadas"] },
  { id: "pro", name: "Pro", price: "R$ 39", period: "por mês", features: ["Currículos e matches ilimitados", "ATS Analyzer avançado", "Versões personalizadas por vaga", "AI Copilot", "Insights de carreira", "Histórico completo"] },
] as const;

function PlanPage() {
  const { data: profile } = useProfile();
  const current = profile?.plan ?? "free";
  return (
    <>
      <PageHeader title="Plano e cobrança" description="Comece grátis. Evolua quando a busca ficar séria." />
      <div className="grid gap-6 md:grid-cols-2">
        {PLANS.map((p) => {
          const active = p.id === current;
          return (
            <div key={p.id} className={cn("surface relative flex flex-col p-6", p.id === "pro" && "border-primary shadow-glow")}>
              {p.id === "pro" && <Badge className="absolute -top-2.5 left-6"><Sparkles className="size-3" /> Recomendado</Badge>}
              <div className="flex items-baseline justify-between"><h3 className="text-lg font-semibold">{p.name}</h3>{active && <Badge variant="soft">Seu plano</Badge>}</div>
              <div className="mt-2"><span className="text-3xl font-semibold tracking-tight">{p.price}</span> <span className="text-sm text-muted-foreground">{p.period}</span></div>
              <ul className="mt-5 flex-1 space-y-2 text-sm">{p.features.map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-primary" /> {f}</li>)}</ul>
              {p.id === "pro" ? (
                <div className="mt-6 space-y-2">
                  <Button className="w-full" disabled>Assinar Pro</Button>
                  <p className="text-center text-xs text-subtle">Pagamentos ainda não ativados. A estrutura está pronta para Stripe.</p>
                </div>
              ) : (
                <Button className="mt-6 w-full" variant="outline" disabled>{active ? "Plano atual" : "Downgrade"}</Button>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}
