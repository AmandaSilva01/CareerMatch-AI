import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Lock, Trash2, Laptop, Download } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { local } from "@/lib/data/local-store";
import { useProfileBundle, useUpsertProfile, useInvalidate } from "@/lib/data/queries";
import { PageHeader } from "@/components/career/Primitives";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({ meta: [{ title: `Configurações · ${BRAND.name}` }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { profile } = useProfileBundle();
  const upsert = useUpsertProfile();
  const invalidate = useInvalidate();
  const navigate = useNavigate();

  function exportData() {
    const blob = new Blob([JSON.stringify(local.snapshot(), null, 2)], { type: "application/json" });
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: "careermatch-meus-dados.json" });
    a.click();
  }

  async function deleteAllData() {
    local.wipe();
    await invalidate(["profiles", "experiences", "education", "skills", "jobs", "matches", "resumes", "applications"]);
    toast.success("Seus dados foram apagados deste navegador.");
    navigate({ to: "/dashboard" });
  }

  return (
    <>
      <PageHeader title="Configurações" description="Privacidade e seus dados." />
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="surface space-y-4 p-6">
          <h3 className="flex items-center gap-2 font-semibold"><ShieldCheck className="size-4 text-primary" /> Privacidade e IA</h3>
          <label className="flex items-start justify-between gap-4 text-sm">
            <span><span className="font-medium">Permitir análise por IA</span><br /><span className="text-muted-foreground">Seu perfil e vagas são enviados ao provedor de IA apenas para gerar análises. Sem isso, match e geração ficam indisponíveis.</span></span>
            <Switch checked={!!profile?.ai_consent} onCheckedChange={(c) => upsert.mutate({ ai_consent: c })} />
          </label>
          <ul className="space-y-1.5 text-sm text-muted-foreground">
          <li className="flex gap-2"><Lock className="mt-0.5 size-4 shrink-0" /> Seus currículos nunca são publicados nem compartilhados.</li>
            <li className="flex gap-2"><Lock className="mt-0.5 size-4 shrink-0" /> A IA nunca inventa experiências, números ou cargos — só reorganiza o que você informou.</li>
          </ul>
          <Link to="/privacidade" className="text-sm font-medium text-primary hover:underline">Ler política de privacidade e segurança</Link>
        </section>

        <section className="surface space-y-4 p-6">
          <h3 className="flex items-center gap-2 font-semibold"><Laptop className="size-4 text-primary" /> Seus dados neste navegador</h3>
          <p className="text-sm text-muted-foreground">
            Você usa o {BRAND.name} sem conta e sem senha. Tudo o que você cria fica salvo apenas neste navegador, neste
            dispositivo: não acompanha você em outro celular ou computador e some se você limpar os dados de navegação.
            Faça uma exportação sempre que quiser guardar uma cópia.
          </p>
        </section>

        <section className="surface space-y-4 p-6 lg:col-span-2">
          <h3 className="font-semibold">Seus dados</h3>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={exportData}><Download /> Exportar meus dados (JSON)</Button>
            <AlertDialog>
              <AlertDialogTrigger asChild><Button variant="destructive"><Trash2 /> Apagar todos os meus dados</Button></AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader><AlertDialogTitle>Apagar tudo?</AlertDialogTitle><AlertDialogDescription>Experiências, competências, vagas, matches, currículos e candidaturas serão removidos permanentemente. Sua conta de acesso permanece.</AlertDialogDescription></AlertDialogHeader>
                <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={deleteAllData}>Apagar</AlertDialogAction></AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </section>
      </div>
    </>
  );
}
