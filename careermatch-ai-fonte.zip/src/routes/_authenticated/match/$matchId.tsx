import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Briefcase, RefreshCw } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { jobsQuery, matchesQuery } from "@/lib/data/queries";
import { useProvideCopilotContext } from "@/lib/copilot-context";
import { useAnalyzeJob } from "@/lib/flows/analyze-job";
import { PageHeader, EmptyState } from "@/components/career/Primitives";
import { MatchAnalysis } from "@/components/career/MatchAnalysis";
import { AIProcessing, MATCH_STEPS } from "@/components/career/AIProcessing";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/match/$matchId")({
  head: () => ({ meta: [{ title: `Análise de match · ${BRAND.name}` }] }),
  component: MatchDetail,
});

function MatchDetail() {
  const { matchId } = Route.useParams();
  const matches = useQuery(matchesQuery);
  const jobs = useQuery(jobsQuery);
  const match = matches.data?.find((m) => m.id === matchId);
  const job = match ? jobs.data?.find((j) => j.id === match.job_id) : undefined;
  const flow = useAnalyzeJob();
  useProvideCopilotContext({ job: job?.parsed_data ?? null, match: match?.analysis ?? null });

  if (matches.isLoading || jobs.isLoading) return <Skeleton className="h-96 rounded-xl" />;
  if (!match) return <EmptyState icon={Briefcase} title="Análise não encontrada" description="Ela pode ter sido removida." actions={<Button asChild><Link to="/match">Voltar</Link></Button>} />;
  if (flow.stage === "matching") return <AIProcessing steps={MATCH_STEPS} active title="Recalculando seu match" />;

  return (
    <>
      <Link to="/match" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Meus matches</Link>
      <PageHeader
        eyebrow="Passo 2 de 3 · Match"
        title={job?.title ?? "Vaga"}
        description={[job?.company, job?.location, job?.work_model].filter(Boolean).join(" · ") || "Detalhes não informados"}
        actions={
          <>
            {job && <Button asChild variant="outline"><Link to="/vagas/$jobId" params={{ jobId: job.id }}><Briefcase /> Ver vaga</Link></Button>}
            {job && <Button variant="ghost" onClick={() => flow.rematch(job)}><RefreshCw /> Recalcular</Button>}
          </>
        }
      />
      <MatchAnalysis match={match.analysis} matchId={match.id} jobTitle={job?.title} />
    </>
  );
}
