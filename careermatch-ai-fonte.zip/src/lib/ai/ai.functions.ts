/**
 * AI Service — typed server functions the UI calls.
 * parseResume · parseJob · calculateMatch · optimizeResume · analyzeATS · generateInsights · askCopilot
 * Each runs as the signed-in user; the provider is abstracted in provider.server.ts.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  ATSResultSchema,
  InsightsSchema,
  MatchResultSchema,
  OptimizedResumeSchema,
  ParsedJobSchema,
  ParsedResumeSchema,
  ProfileSnapshotSchema,
  ResumeContentSchema,
  matchLabel,
} from "./schemas";

async function ai() {
  return import("./provider.server");
}

async function run<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    console.error("[ai]", err);
    const { humanizeAIError } = await ai();
    throw new Error(humanizeAIError(err));
  }
}

export const parseResume = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        text: z.string().nullable(),
        file: z.object({ base64: z.string(), mediaType: z.string(), filename: z.string() }).nullable(),
      })
      .parse(input),
  )
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      return generateStructured({
        system: `Você é um parser de currículos. Extraia APENAS o que está escrito no documento, sem inferir nada. ${FACTUALITY_RULES}`,
        prompt: data.text
          ? `Extraia os dados estruturados deste currículo:\n\n${data.text.slice(0, 30000)}`
          : "Extraia os dados estruturados do currículo em anexo.",
        file: data.file ?? undefined,
        schema: ParsedResumeSchema,
      });
    }),
  );

export const parseJob = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ description: z.string().min(30) }).parse(input))
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      return generateStructured({
        system: `Você é um analisador de vagas de emprego. Transforme a descrição em dados estruturados. Use null quando um campo não for mencionado. Palavras-chave devem ser termos concretos que um ATS buscaria. ${FACTUALITY_RULES}`,
        prompt: `Descrição da vaga:\n\n${data.description.slice(0, 20000)}`,
        schema: ParsedJobSchema,
      });
    }),
  );

export const calculateMatch = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ profile: ProfileSnapshotSchema, job: ParsedJobSchema }).parse(input))
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      const result = await generateStructured({
        system: `Você é um motor de matching entre perfil profissional e vaga. Avalie: experiência (vs. responsabilidades), competências técnicas, soft skills, formação, palavras-chave, idiomas e senioridade. Faça análise semântica de equivalências. Scores de 0 a 100 por categoria e um score geral ponderado. Em "gaps" use kind="found" para requisitos claramente ausentes, "inference" quando você deduz, "recommendation" para sugestões. "disclaimer" deve lembrar que o score é compatibilidade estimada, não probabilidade de contratação. ${FACTUALITY_RULES}`,
        prompt: `PERFIL DO CANDIDATO:\n${JSON.stringify(data.profile)}\n\nVAGA ESTRUTURADA:\n${JSON.stringify(data.job)}`,
        schema: MatchResultSchema,
        effort: "medium",
      });
      const score = Math.max(0, Math.min(100, Math.round(result.score)));
      return { ...result, score, label: matchLabel(score) };
    }),
  );

export const optimizeResume = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        profile: ProfileSnapshotSchema,
        job: ParsedJobSchema.nullable(),
        match: MatchResultSchema.nullable(),
        baseResume: ResumeContentSchema.nullable(),
        instruction: z.string().nullable(),
      })
      .parse(input),
  )
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      return generateStructured({
        system: `Você é um redator de currículos otimizados para ATS. Você DEVE: adaptar o resumo profissional à vaga, reorganizar e destacar experiências relevantes, enfatizar competências relacionadas, incorporar palavras-chave da vaga SOMENTE quando verdadeiras no perfil, transformar atividades em realizações quando houver evidência, melhorar clareza e objetividade, usar linguagem profissional. Liste em "changes" o que foi alterado e em "notIdentified" requisitos da vaga que NÃO existem no perfil (não os inclua no currículo). Formato simples, sem tabelas, sem gráficos. ${FACTUALITY_RULES}`,
        prompt: `PERFIL:\n${JSON.stringify(data.profile)}\n\nVAGA:\n${data.job ? JSON.stringify(data.job) : "Nenhuma vaga específica — crie um currículo base forte."}\n\nANÁLISE DE MATCH:\n${data.match ? JSON.stringify(data.match) : "n/a"}\n\nCURRÍCULO BASE:\n${data.baseResume ? JSON.stringify(data.baseResume) : "n/a"}\n\nINSTRUÇÃO ADICIONAL:\n${data.instruction ?? "nenhuma"}`,
        schema: OptimizedResumeSchema,
        effort: "medium",
      });
    }),
  );

export const analyzeATS = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ resume: ResumeContentSchema, job: ParsedJobSchema.nullable() }).parse(input))
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      return generateStructured({
        system: `Você é um analisador ATS (Applicant Tracking System). Avalie o currículo de 0 a 100 nas categorias: structure, keywords, readability, experience, skills, formatting. Liste problemas (type="warning") e pontos corretos (type="ok"), com "fix" sugerindo correção concreta quando aplicável. "missingKeywords" = palavras-chave da vaga ausentes no currículo (apenas se houver vaga). ${FACTUALITY_RULES}`,
        prompt: `CURRÍCULO:\n${JSON.stringify(data.resume)}\n\nVAGA:\n${data.job ? JSON.stringify(data.job) : "Sem vaga associada — avalie de forma geral."}`,
        schema: ATSResultSchema,
      });
    }),
  );

export const generateInsights = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ profile: ProfileSnapshotSchema, jobs: z.array(ParsedJobSchema) }).parse(input))
  .handler(async ({ data }) =>
    run(async () => {
      const { generateStructured, FACTUALITY_RULES } = await ai();
      return generateStructured({
        system: `Você é um analista de carreira. Compare as competências do perfil com as competências mais frequentes nas vagas analisadas pelo usuário. "topSkills" = competências mais recorrentes do perfil. "marketSkills" = competências frequentes nas vagas com status has/partial/missing e frequency (quantas vagas pedem). Dê recomendações práticas. ${FACTUALITY_RULES}`,
        prompt: `PERFIL:\n${JSON.stringify(data.profile)}\n\nVAGAS ANALISADAS (${data.jobs.length}):\n${JSON.stringify(data.jobs.slice(0, 15))}`,
        schema: InsightsSchema,
      });
    }),
  );

export const askCopilot = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).min(1),
        context: z.object({
          profile: ProfileSnapshotSchema.nullable(),
          job: ParsedJobSchema.nullable(),
          match: MatchResultSchema.nullable(),
          resume: ResumeContentSchema.nullable(),
        }),
      })
      .parse(input),
  )
  .handler(async ({ data }) =>
    run(async () => {
      const { generateChat, FACTUALITY_RULES } = await ai();
      const reply = await generateChat({
        system: `Você é o AI Copilot do CareerMatch AI, um assistente de carreira objetivo e cordial. Responda de forma curta e prática (máximo ~180 palavras), em markdown leve. Use o contexto abaixo. ${FACTUALITY_RULES}\n\nCONTEXTO:\nPERFIL: ${JSON.stringify(data.context.profile)}\nVAGA: ${JSON.stringify(data.context.job)}\nMATCH: ${JSON.stringify(data.context.match)}\nCURRÍCULO: ${JSON.stringify(data.context.resume)}`,
        messages: data.messages.slice(-12),
      });
      return { reply };
    }),
  );
