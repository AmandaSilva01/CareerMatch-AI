/** Browser-side export: PDF via print stylesheet (ATS-friendly text), DOCX via `docx`. */
import type { ResumeContent } from "@/lib/ai/schemas";

export function exportResumePdf(name: string) {
  const prev = document.title;
  document.title = name.replace(/[^\w\-\u00C0-\u017F ]+/g, "").trim() || "curriculo";
  window.print();
  setTimeout(() => (document.title = prev), 1000);
}

export async function exportResumeDocx(resume: ResumeContent, name: string) {
  const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } = await import("docx");
  const contact = [resume.contact.city, resume.contact.email, resume.contact.phone, resume.contact.linkedin, resume.contact.github, resume.contact.portfolio].filter(Boolean).join(" | ");
  const h = (text: string) => new Paragraph({ text: text.toUpperCase(), heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 100 }, border: { bottom: { style: "single", size: 6, color: "222222", space: 2 } } });
  const p = (text: string, opts: { bold?: boolean; italics?: boolean; size?: number; after?: number } = {}) =>
    new Paragraph({ children: [new TextRun({ text, bold: opts.bold ?? false, italics: opts.italics ?? false, size: opts.size ?? 22 })], spacing: { after: opts.after ?? 60 } });
  const bullet = (text: string) => new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 40 } });

  const children: InstanceType<typeof Paragraph>[] = [
    new Paragraph({ children: [new TextRun({ text: resume.fullName, bold: true, size: 40 })], alignment: AlignmentType.LEFT, spacing: { after: 40 } }),
  ];
  if (resume.headline) children.push(p(resume.headline, { bold: true, size: 24 }));
  if (contact) children.push(p(contact, { size: 20, after: 120 }));
  if (resume.summary) children.push(h("Resumo profissional"), p(resume.summary));
  if (resume.experiences.length) {
    children.push(h("Experiência profissional"));
    for (const e of resume.experiences) {
      children.push(p(`${e.role} — ${e.company}`, { bold: true, after: 0 }), p(e.period, { italics: true, size: 20 }));
      e.bullets.forEach((b) => children.push(bullet(b)));
    }
  }
  if (resume.education.length) {
    children.push(h("Formação acadêmica"));
    for (const e of resume.education) children.push(p(`${[e.degree, e.course].filter(Boolean).join(" em ")} — ${e.institution}`, { bold: true, after: 0 }), p(e.period, { italics: true, size: 20 }));
  }
  if (resume.skills.length) children.push(h("Competências"), p(resume.skills.join(" · ")));
  if (resume.certifications.length) children.push(h("Certificações"), ...resume.certifications.map(bullet));
  if (resume.languages.length) children.push(h("Idiomas"), p(resume.languages.join(" · ")));

  const doc = new Document({
    styles: { default: { document: { run: { font: "Arial", size: 22 } } } },
    sections: [{ properties: { page: { margin: { top: 900, bottom: 900, left: 900, right: 900 } } }, children }],
  });
  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement("a"), { href: url, download: `${name || "curriculo"}.docx` });
  a.click();
  URL.revokeObjectURL(url);
}
