import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Save, Copy, ScanSearch, Sparkles, FileDown, FileType, FileText, Eye, PencilLine } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { analyzeATS, optimizeResume } from "@/lib/ai/ai.functions";
import type { ATSResult, ResumeContent } from "@/lib/ai/schemas";
import { jobsQuery, matchesQuery, resumesQuery, toProfileSnapshot, useInsert, useProfileBundle, useUpdate } from "@/lib/data/queries";
import { exportResumeDocx, exportResumePdf } from "@/lib/resume-export";
import { useProvideCopilotContext } from "@/lib/copilot-context";
import { ResumeEditor } from "@/components/career/ResumeEditor";
import { ResumePreview } from "@/components/career/ResumePreview";
import { ATSPanel } from "@/components/career/ATSPanel";
import { AIProcessing, ATS_STEPS, RESUME_STEPS } from "@/components/career/AIProcessing";
import { EmptyState, NextStep, ErrorNotice } from "@/components/career/Primitives";
import { MatchPill } from "@/components/career/MatchScore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export const Route = createFileRoute("/_authenticated/curriculos/$resumeId")({
  head: () => ({ meta: [{ title: `Editor de currículo · ${BRAND.name}` }] }),
  component: ResumeEditorPage,
});

function ResumeEditorPage() {
  const { resumeId } = Route.useParams();
  const navigate = useNavigate();
  const resumes = useQuery(resumesQuery);
  const jobs = useQuery(jobsQuery);
  const matches = useQuery(matchesQuery);
  const bundle = useProfileBundle();
  const update = useUpdate("resumes");
  const insert = useInsert("resumes");
  const ats = useServerFn(analyzeATS);
  const optimize = useServerFn(optimizeResume);

  const resume = resumes.data?.find((r) => r.id === resumeId);
  const job = resume?.job_id ? jobs.data?.find((j) => j.id === resume.job_id) : undefined;
  const match = job ? [...(matches.data ?? [])].filter((m) => m.job_id === job.id).sort((a, b) => b.created_at.localeCompare(a.created_at))[0] : undefined;

  const [draft, setDraft] = useState<ResumeContent | null>(null);
  const [name, setName] = useState("");
  const [dirty, setDirty] = useState(false);
  const [atsResult, setAtsResult] = useState<ATSResult | null>(null);
  const [busy, setBusy] = useState<"ats" | "ai" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiInstruction, setAiInstruction] = useState("");
  const [mobileTab, setMobileTab] = useState<"edit" | "preview">("edit");

  useEffect(() => {
    if (resume && !draft) {
      setDraft(resume.content);
      setName(resume.name);
      setAtsResult(resume.ats_analysis);
    }
  }, [resume, draft]);

  useProvideCopilotContext({ job: job?.parsed_data ?? null, match: match?.analysis ?? null, resume: draft });

  if (resumes.isLoading || !draft) return <Skeleton className="h-[70vh] rounded-xl" />;
  if (!resume) return <EmptyState icon={FileText} title="Currículo não encontrado" description="Ele pode ter sido excluído." actions={<Button asChild><Link to="/curriculos">Meus currículos</Link></Button>} />;

  const change = (next: ResumeContent) => { setDraft(next); setDirty(true); };

  async function save(): Promise<boolean> {
    try {
      await update.mutateAsync({ id: resumeId, patch: { content: draft, name, ats_score: atsResult?.score ?? null, ats_analysis: atsResult } as never });
      setDirty(false);
      toast.success("Currículo salvo.");
      return true;
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível salvar.");
      return false;
    }
  }
  async function saveAsNew() {
    const row = await insert.mutateAsync({ name: `${name} (cópia)`, is_base: false, base_resume_id: resumeId, job_id: resume!.job_id, content: draft, match_score: resume!.match_score } as never);
    toast.success("Nova versão criada.");
    navigate({ to: "/curriculos/$resumeId", params: { resumeId: row.id } });
    setDraft(null);
  }
  async function runATS() {
    setBusy("ats"); setError(null);
    try {
      const r = await ats({ data: { resume: draft!, job: job?.parsed_data ?? null } });
      setAtsResult(r);
      await update.mutateAsync({ id: resumeId, patch: { ats_score: r.score, ats_analysis: r } as never });
      toast.success(`ATS Score: ${r.score}/100`);
    } catch (e) { setError(e instanceof Error ? e.message : "Não conseguimos analisar agora."); }
    finally { setBusy(null); }
  }
  async function improve(instruction: string) {
    setBusy("ai"); setError(null); setAiOpen(false);
    try {
      const out = await optimize({ data: { profile: toProfileSnapshot(bundle), job: job?.parsed_data ?? null, match: match?.analysis ?? null, baseResume: draft, instruction } });
      change(out.resume);
      toast.success("Currículo melhorado. Revise as alterações.", { description: out.changes.slice(0, 3).join(" · ") });
    } catch (e) { setError(e instanceof Error ? e.message : "Não conseguimos melhorar agora. Seu texto foi preservado."); }
    finally { setBusy(null); }
  }

  const next = !atsResult
    ? { title: "Analisar no ATS", description: "Veja se sistemas de triagem vão ler bem o seu currículo.", cta: "Analisar ATS", onClick: runATS }
    : atsResult.issues.some((i) => i.type === "warning")
      ? { title: "Corrigir problemas apontados", description: "A IA ajusta o texto sem inventar nada.", cta: "Corrigir com IA", onClick: () => improve(`Corrija: ${atsResult.issues.filter((i) => i.type === "warning").map((i) => i.message).join("; ")}`) }
      : { title: "Salvar e exportar", description: "Seu currículo está pronto para a candidatura.", cta: "Exportar PDF", onClick: async () => { if (await save()) exportResumePdf(name); } };

  return (
    <>
      <div className="print:hidden">
        <Link to="/curriculos" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Meus currículos</Link>
        <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <Input value={name} onChange={(e) => { setName(e.target.value); setDirty(true); }} className="h-9 max-w-xs text-base font-semibold" aria-label="Nome do currículo" />
            {match && <MatchPill score={match.score} />}
            {dirty && <span className="text-xs text-warning">Não salvo</span>}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={save} disabled={update.isPending}><Save /> Salvar</Button>
            <Button variant="ghost" size="sm" onClick={saveAsNew}><Copy /> Salvar como nova versão</Button>
            <Button variant="soft" size="sm" onClick={runATS} disabled={!!busy}><ScanSearch /> Analisar ATS</Button>
            <Button variant="ai" size="sm" onClick={() => setAiOpen(true)} disabled={!!busy}><Sparkles /> Melhorar com IA</Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button size="sm"><FileDown /> Exportar</Button></DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => exportResumePdf(name)}><FileDown /> PDF (ATS)</DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportResumeDocx(draft, name)}><FileType /> DOCX</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {error && <div className="mb-4"><ErrorNotice message={error} onRetry={() => setError(null)} /></div>}
        {busy === "ai" && <div className="mb-4"><AIProcessing steps={RESUME_STEPS} active title="Melhorando seu currículo" /></div>}
        {busy === "ats" && <div className="mb-4"><AIProcessing steps={ATS_STEPS} active title="Analisando compatibilidade com ATS" /></div>}

        <Tabs value={mobileTab} onValueChange={(v) => setMobileTab(v as "edit" | "preview")} className="mb-3 lg:hidden">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="edit"><PencilLine className="size-3.5" /> Editor</TabsTrigger>
            <TabsTrigger value="preview"><Eye className="size-3.5" /> Preview</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className={`space-y-4 print:hidden ${mobileTab === "preview" ? "hidden lg:block" : ""}`}>
          <NextStep {...next} />
          <ResumeEditor value={draft} onChange={change} />
          {atsResult && (
            <div className="surface p-5">
              <h3 className="mb-4 text-sm font-semibold">Análise ATS</h3>
              <ATSPanel result={atsResult} onFix={improve} fixing={busy === "ai"} />
            </div>
          )}
        </div>
        <div className={`${mobileTab === "edit" ? "hidden lg:block" : ""}`}>
          <div className="lg:sticky lg:top-8">
            <div className="mb-2 flex items-center justify-between print:hidden"><span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Preview · modelo ATS</span><span className="text-xs text-subtle">A4</span></div>
            <div className="overflow-hidden rounded-xl border shadow-card print:border-0 print:shadow-none">
              <ResumePreview resume={draft} />
            </div>
          </div>
        </div>
      </div>

      <Sheet open={aiOpen} onOpenChange={setAiOpen}>
        <SheetContent>
          <SheetHeader><SheetTitle className="flex items-center gap-2"><Sparkles className="size-4 text-primary" /> Melhorar com IA</SheetTitle><SheetDescription>Diga o que ajustar. A IA mantém os fatos do seu perfil.</SheetDescription></SheetHeader>
          <div className="space-y-3 px-4">
            {["Deixe o resumo mais objetivo (3 linhas)", "Transforme atividades em realizações com verbos de ação", "Reforce as palavras-chave da vaga que forem verdadeiras", "Reduza para caber em uma página"].map((s) => (
              <button key={s} onClick={() => improve(s)} className="block w-full rounded-lg border px-3 py-2 text-left text-sm transition-colors hover:border-primary-muted hover:bg-accent">{s}</button>
            ))}
            <div className="space-y-1.5 pt-2"><Label>Instrução personalizada</Label><Textarea rows={3} value={aiInstruction} onChange={(e) => setAiInstruction(e.target.value)} /></div>
            <Button className="w-full" variant="ai" disabled={!aiInstruction.trim()} onClick={() => improve(aiInstruction)}><Sparkles /> Aplicar</Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
