/** Shared option lists used across onboarding, profile and job filters. */
export const AREAS = ["Dados", "Tecnologia", "Marketing", "Finanças", "RH", "Produto", "Customer Success", "Engenharia", "Administração"] as const;
export const SENIORITIES = ["Estágio", "Júnior", "Pleno", "Sênior", "Liderança"] as const;
export const WORK_MODELS = ["Remoto", "Híbrido", "Presencial"] as const;
export const SKILL_CATEGORIES = [
  { value: "technical", label: "Técnicas" },
  { value: "tool", label: "Ferramentas" },
  { value: "soft", label: "Soft skills" },
  { value: "language", label: "Idiomas" },
  { value: "certification", label: "Certificações" },
] as const;
export type SkillCategory = (typeof SKILL_CATEGORIES)[number]["value"];

export const APPLICATION_STATUSES = [
  { value: "saved", label: "Salva" },
  { value: "planned", label: "Aplicação planejada" },
  { value: "applied", label: "Candidatura enviada" },
  { value: "test", label: "Teste" },
  { value: "interview", label: "Entrevista" },
  { value: "finalist", label: "Finalista" },
  { value: "offer", label: "Oferta" },
  { value: "closed", label: "Encerrada" },
] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number]["value"];
