import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Briefcase, Sparkles, Trash2, KanbanSquare, Target } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { getSuggestedJob } from "@/lib/mock/jobs";
import { jobsQuery, matchesQuery, useInsert, useRemove, type Job } from "@/lib/data/queries";
import { useAnalyzeJob } from "@/lib/flows/analyze-job";
import { useProvideCopilotContext } from "@/lib/copilot-context";
import type { ParsedJob } from "@/lib/ai/schemas";
import { PageHeader, EmptyState, ErrorNotice, NextStep } from "@/components/career/Primitives";
import { MatchRing } from "@/components/career/MatchScore";
import { AIProcessing, MATCH_STEPS } from "@/components/career/AIProcessing";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/_authenticated/vagas/$jobId")({
  head: () => ({ meta: [{ title: `Detalhes da vaga · ${BRAND.name}` }] }),
  component: JobDetail,
});

function JobDetail() {
  const { jobId } = Route.useParams();
  const jobs = useQuery(jobsQuery);
  const matches = useQuery(matchesQuery);
  const flow = useAnalyzeJob();
  const navigate = useNavigate();
  const remove = useRemove("jobs");
  const addApp = useInsert("applications");

  const suggested = getSuggestedJob(jobId);
  const job = jobs.data?.find((j) => j.id === jobId);
  const match = [...(matches.data ?? [])].filter((m) => m.job_id === jobId).sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
  useProvideCopilotContext({ job: job?.parsed_data ?? null, match: match?.analysis ?? null });

  if (flow.stage === "parsing" || flow.stage === "matching") return <AIProcessing steps={MATCH_STEPS} active title="Analisando a vaga e calculando seu match" />;
  if (jobs.isLoading) return <Skeleton className="h-96 rounded-xl" />;

  // Suggested (mock) job not yet saved: show it and offer to analyze.
  if (!job && suggested) {
    return (
      <>
        <Back />
        <PageHeader title={suggested.title} description={`${suggested.company} · ${suggested.location} · ${suggested.workModel}`} actions={<Badge variant="outline">Vaga de exemplo</Badge>} />
        {flow.stage === "error" && flow.error && <div className="mb-6"><ErrorNotice message={flow.error} onRetry={flow.reset} /></div>}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="surface whitespace-pre-line p-6 text-sm leading-relaxed lg:col-span-2">{suggested.description}</div>
          <div className="space-y-4">
            <NextStep title="Calcular meu match" description="A IA estrutura a vaga e compara com seu perfil." cta="Analisar com IA" onClick={async () => {
              const res = await flow.analyze(suggested.description);
              if (res) navigate({ to: "/match/$matchId", params: { matchId: res.match.id } });
            }} />
          </div>
        </div>
      </>
    );
  }

  if (!job) return <EmptyState icon={Briefcase} title="Vaga não encontrada" description="Ela pode ter sido removida." actions={<Button asChild><Link to="/vagas">Voltar</Link></Button>} />;
  const p = job.parsed_data;

  return (
    <>
      <Back />
      <PageHeader
        title={job.title}
        description={[job.company, job.location, job.work_model, job.seniority, job.salary_range].filter(Boolean).join(" · ") || "Detalhes não informados"}
        actions={
          <>
            <Button variant="outline" onClick={async () => {
              await addApp.mutateAsync({ company: job.company ?? "Empresa", role: job.title, job_id: job.id, match_score: match?.score ?? null, status: "saved" } as never);
              toast.success("Vaga adicionada às candidaturas.");
              navigate({ to: "/candidaturas" });
            }}><KanbanSquare /> Salvar candidatura</Button>
            <Button variant="ghost" size="icon" aria-label="Excluir vaga" onClick={async () => {
              await remove.mutateAsync(job.id);
              toast.success("Vaga removida.");
              navigate({ to: "/vagas" });
            }}><Trash2 /></Button>
          </>
        }
      />
      {flow.stage === "error" && flow.error && <div className="mb-6"><ErrorNotice message={flow.error} onRetry={flow.reset} /></div>}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {p ? <ParsedJobView p={p} /> : <div className="surface p-6 text-sm text-muted-foreground">Esta vaga ainda não foi estruturada pela IA.</div>}
          <Accordion type="single" collapsible className="surface px-5">
            <AccordionItem value="raw" className="border-0">
              <AccordionTrigger className="text-sm">Descrição original</AccordionTrigger>
              <AccordionContent className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{job.description}</AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
        <aside className="space-y-4">
          {match ? (
            <div className="surface flex flex-col items-center p-6 text-center">
              <MatchRing score={match.score} size={120} />
              <div className="mt-2 font-semibold">{match.analysis.label}</div>
              <div className="text-xs text-muted-foreground">Compatibilidade com seu perfil</div>
              <Button asChild className="mt-4 w-full"><Link to="/match/$matchId" params={{ matchId: match.id }}><Target /> Ver análise completa</Link></Button>
              <Button asChild variant="soft" className="mt-2 w-full"><Link to="/curriculos/novo" search={{ matchId: match.id }}><Sparkles /> Criar currículo para esta vaga</Link></Button>
            </div>
          ) : (
            <NextStep title="Calcular meu match" description="Veja sua compatibilidade explicada por categoria." cta="Calcular com IA" onClick={async () => {
              const m = await flow.rematch(job as Job);
              if (m) navigate({ to: "/match/$matchId", params: { matchId: m.id } });
            }} />
          )}
        </aside>
      </div>
    </>
  );
}

const Back = () => <Link to="/vagas" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Encontrar vagas</Link>;

export function ParsedJobView({ p }: { p: ParsedJob }) {
  const Section = ({ title, items }: { title: string; items: string[] }) =>
    items.length ? (
      <div>
        <h4 className="mb-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">{title}</h4>
        <div className="flex flex-wrap gap-1.5">{items.map((i) => <Badge key={i} variant="secondary">{i}</Badge>)}</div>
      </div>
    ) : null;
  return (
    <div className="surface space-y-5 p-6">
      <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
        {[["Empresa", p.company], ["Local", p.location], ["Modelo", p.workModel], ["Senioridade", p.seniority]].map(([l, v]) => (
          <div key={l}><div className="text-xs text-muted-foreground">{l}</div><div className="font-medium">{v ?? "Não informado"}</div></div>
        ))}
      </div>
      {p.responsibilities.length > 0 && (
        <div>
          <h4 className="mb-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">Responsabilidades</h4>
          <ul className="list-disc space-y-1 pl-5 text-sm">{p.responsibilities.map((r, i) => <li key={i}>{r}</li>)}</ul>
        </div>
      )}
      <Section title="Requisitos obrigatórios" items={p.requiredSkills} />
      <Section title="Desejáveis" items={p.desiredSkills} />
      <Section title="Competências técnicas" items={p.technicalSkills} />
      <Section title="Soft skills" items={p.softSkills} />
      <Section title="Idiomas" items={p.languages} />
      <Section title="Palavras-chave (ATS)" items={p.keywords} />
    </div>
  );
}
