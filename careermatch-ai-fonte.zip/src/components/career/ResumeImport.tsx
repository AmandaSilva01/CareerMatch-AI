import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Upload, FileText, Check, Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { parseResume } from "@/lib/ai/ai.functions";
import type { ParsedResume } from "@/lib/ai/schemas";
import { fileToParseInput, parsedResumeToRows } from "@/lib/resume-import";
import { local } from "@/lib/data/local-store";
import { useInvalidate } from "@/lib/data/queries";
import { AIProcessing, PARSE_STEPS } from "@/components/career/AIProcessing";
import { ErrorNotice } from "@/components/career/Primitives";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Stage = { kind: "idle" } | { kind: "parsing" } | { kind: "review"; parsed: ParsedResume } | { kind: "saving" } | { kind: "error"; message: string };

/**
 * Upload PDF/DOCX (or paste text) → AI extracts → user reviews/edits → saved into profile tables.
 * `replace` clears existing experiences/education/skills before inserting.
 */
export function ResumeImport({ onDone, replace = true }: { onDone?: (parsed: ParsedResume) => void; replace?: boolean }) {
  const [stage, setStage] = useState<Stage>({ kind: "idle" });
  const [text, setText] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const parse = useServerFn(parseResume);
  const invalidate = useInvalidate();

  async function runParse(input: Awaited<ReturnType<typeof fileToParseInput>>) {
    setStage({ kind: "parsing" });
    try {
      const parsed = await parse({ data: input });
      setStage({ kind: "review", parsed });
    } catch (e) {
      setStage({ kind: "error", message: e instanceof Error ? e.message : "Não conseguimos ler o currículo agora. Suas informações foram preservadas." });
    }
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    try {
      await runParse(await fileToParseInput(file));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Arquivo inválido");
    }
  }

  async function save(parsed: ParsedResume) {
    setStage({ kind: "saving" });
    try {
      const rows = parsedResumeToRows(parsed);
      if (replace) {
        local.clear("experiences");
        local.clear("education");
        local.clear("skills");
      }
      const profilePatch = Object.fromEntries(Object.entries(rows.profile).filter(([, v]) => v !== null && v !== ""));
      local.upsertProfile(profilePatch);
      rows.experiences.forEach((r) => local.insert("experiences", r as Record<string, unknown>));
      rows.education.forEach((r) => local.insert("education", r as Record<string, unknown>));
      rows.skills.forEach((r) => local.insert("skills", r as Record<string, unknown>));
      await invalidate(["profiles", "experiences", "education", "skills"]);
      toast.success("Perfil atualizado com os dados do currículo.");
      onDone?.(parsed);
      setStage({ kind: "idle" });
    } catch (e) {
      setStage({ kind: "error", message: e instanceof Error ? e.message : "Não foi possível salvar." });
    }
  }

  if (stage.kind === "parsing") return <AIProcessing steps={PARSE_STEPS} active title="Lendo seu currículo" />;
  if (stage.kind === "saving") return <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin text-primary" /> Salvando no seu perfil…</div>;
  if (stage.kind === "error") return <ErrorNotice message={stage.message} onRetry={() => setStage({ kind: "idle" })} />;
  if (stage.kind === "review") return <ReviewStep parsed={stage.parsed} onConfirm={save} onCancel={() => setStage({ kind: "idle" })} />;

  return (
    <Tabs defaultValue="file">
      <TabsList className="mb-4">
        <TabsTrigger value="file"><Upload className="size-3.5" /> Enviar arquivo</TabsTrigger>
        <TabsTrigger value="text"><FileText className="size-3.5" /> Colar texto</TabsTrigger>
      </TabsList>
      <TabsContent value="file">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            onFile(e.dataTransfer.files[0]);
          }}
          className="flex w-full flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-card px-6 py-12 text-center transition-colors hover:border-primary-muted hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <span className="mb-3 rounded-xl bg-primary-soft p-3 text-primary"><Upload className="size-5" /></span>
          <span className="font-medium">Arraste seu currículo ou clique para selecionar</span>
          <span className="mt-1 text-xs text-muted-foreground">PDF ou DOCX · até 10 MB · a IA extrai as informações e você confirma antes de salvar</span>
        </button>
        <input ref={fileRef} type="file" accept=".pdf,.docx,.txt" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
      </TabsContent>
      <TabsContent value="text" className="space-y-3">
        <Textarea rows={10} value={text} onChange={(e) => setText(e.target.value)} placeholder="Cole aqui o conteúdo do seu currículo…" />
        <Button disabled={text.trim().length < 50} onClick={() => runParse({ text, file: null })}>Extrair com IA</Button>
      </TabsContent>
    </Tabs>
  );
}

function ReviewStep({ parsed, onConfirm, onCancel }: { parsed: ParsedResume; onConfirm: (p: ParsedResume) => void; onCancel: () => void }) {
  const [p, setP] = useState(parsed);
  const field = (k: keyof ParsedResume, label: string) =>
    typeof p[k] === "string" || p[k] === null ? (
      <div key={k} className="space-y-1">
        <Label className="text-xs">{label}</Label>
        <Input value={(p[k] as string | null) ?? ""} onChange={(e) => setP({ ...p, [k]: e.target.value || null })} />
      </div>
    ) : null;
  const list = (k: "technicalSkills" | "tools" | "softSkills" | "languages" | "certifications", label: string) => (
    <div key={k} className="space-y-1">
      <Label className="text-xs">{label} <span className="text-subtle">(separe por vírgula)</span></Label>
      <Input value={p[k].join(", ")} onChange={(e) => setP({ ...p, [k]: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} />
    </div>
  );
  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3 rounded-xl border border-success/30 bg-success-soft p-4 text-sm">
        <Check className="mt-0.5 size-4 text-success" />
        <div>
          <p className="font-medium">Encontramos {p.experiences.length} experiências, {p.education.length} formações e {p.technicalSkills.length + p.tools.length} competências.</p>
          <p className="text-muted-foreground">Revise abaixo. Só o que está aqui será salvo — nada é inventado.</p>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {field("fullName", "Nome completo")}
        {field("headline", "Cargo / título")}
        {field("email", "E-mail")}
        {field("phone", "Telefone")}
        {field("city", "Cidade")}
        {field("linkedin", "LinkedIn")}
      </div>
      <div className="space-y-1">
        <Label className="text-xs">Resumo profissional</Label>
        <Textarea rows={3} value={p.summary ?? ""} onChange={(e) => setP({ ...p, summary: e.target.value || null })} />
      </div>
      <div className="space-y-2">
        <Label className="text-xs">Experiências</Label>
        {p.experiences.length === 0 && <p className="text-sm text-subtle">Não identificado no documento.</p>}
        {p.experiences.map((e, i) => (
          <div key={i} className="rounded-lg border p-3 text-sm">
            <div className="flex items-center justify-between gap-2">
              <div className="font-medium">{e.role} · <span className="text-muted-foreground">{e.company}</span></div>
              <Badge variant="outline">{[e.startDate, e.isCurrent ? "Atual" : e.endDate].filter(Boolean).join(" – ") || "Período não identificado"}</Badge>
            </div>
            {e.description && <p className="mt-1 text-muted-foreground">{e.description}</p>}
          </div>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {list("technicalSkills", "Competências técnicas")}
        {list("tools", "Ferramentas")}
        {list("softSkills", "Soft skills")}
        {list("languages", "Idiomas")}
        {list("certifications", "Certificações")}
      </div>
      <p className="text-xs text-subtle"><Pencil className="mr-1 inline size-3" /> Você poderá editar experiências e formação em detalhe na página Meu Perfil.</p>
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onCancel}>Cancelar</Button>
        <Button onClick={() => onConfirm(p)}><Check /> Confirmar e salvar</Button>
      </div>
    </div>
  );
}
