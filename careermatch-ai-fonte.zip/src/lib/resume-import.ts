/** Browser-side helpers to turn an uploaded PDF/DOCX into something the AI parser accepts. */
import type { ParsedResume } from "@/lib/ai/schemas";
import type { TablesInsert } from "@/integrations/supabase/types";

export type ParseInput = { text: string | null; file: { base64: string; mediaType: string; filename: string } | null };

export async function fileToParseInput(file: File): Promise<ParseInput> {
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".docx")) {
    const mammoth = await import("mammoth");
    const { value } = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return { text: value, file: null };
  }
  if (lower.endsWith(".txt") || lower.endsWith(".md")) return { text: await file.text(), file: null };
  if (lower.endsWith(".pdf") || file.type === "application/pdf") {
    const buf = new Uint8Array(await file.arrayBuffer());
    let bin = "";
    for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
    return { text: null, file: { base64: btoa(bin), mediaType: "application/pdf", filename: file.name } };
  }
  throw new Error("Formato não suportado. Envie PDF, DOCX ou TXT.");
}

/** Splits a parsed resume into table rows (user_id is added by the mutation layer). */
export function parsedResumeToRows(p: ParsedResume) {
  const skills: Omit<TablesInsert<"skills">, "user_id">[] = [
    ...p.technicalSkills.map((name) => ({ name, category: "technical" })),
    ...p.tools.map((name) => ({ name, category: "tool" })),
    ...p.softSkills.map((name) => ({ name, category: "soft" })),
    ...p.languages.map((name) => ({ name, category: "language" })),
    ...p.certifications.map((name) => ({ name, category: "certification" })),
  ];
  const experiences: Omit<TablesInsert<"experiences">, "user_id">[] = p.experiences.map((e, i) => ({
    company: e.company,
    role: e.role,
    start_date: e.startDate,
    end_date: e.endDate,
    is_current: e.isCurrent,
    description: e.description,
    achievements: e.achievements,
    sort_order: i,
  }));
  const education: Omit<TablesInsert<"education">, "user_id">[] = p.education.map((e) => ({
    institution: e.institution,
    course: e.course,
    degree: e.degree,
    start_date: e.startDate,
    end_date: e.endDate,
  }));
  const profile = {
    full_name: p.fullName,
    email: p.email,
    phone: p.phone,
    city: p.city,
    linkedin: p.linkedin,
    github: p.github,
    portfolio: p.portfolio,
    headline: p.headline,
    summary: p.summary,
  };
  return { profile, experiences, education, skills };
}
