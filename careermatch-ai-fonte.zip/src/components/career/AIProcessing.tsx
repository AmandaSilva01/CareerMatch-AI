import { useEffect, useState } from "react";
import { Check, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

/** Multi-step AI loading state. Steps advance on a timer while the request is in flight. */
export function AIProcessing({ steps, active, title = "A IA está trabalhando" }: { steps: string[]; active: boolean; title?: string }) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    if (!active) { setIdx(0); return; }
    const t = setInterval(() => setIdx((i) => Math.min(i + 1, steps.length - 1)), 1800);
    return () => clearInterval(t);
  }, [active, steps.length]);
  if (!active) return null;
  return (
    <div className="surface animate-fade-in p-6">
      <div className="mb-4 flex items-center gap-2">
        <span className="rounded-lg bg-ai-gradient p-1.5 text-primary-foreground"><Sparkles className="size-4" /></span>
        <span className="font-medium">{title}</span>
      </div>
      <ul className="space-y-2.5">
        {steps.map((s, i) => (
          <li key={s} className={cn("flex items-center gap-2.5 text-sm transition-colors", i < idx ? "text-muted-foreground" : i === idx ? "text-foreground" : "text-subtle")}>
            {i < idx ? <Check className="size-4 text-success" /> : i === idx ? <Loader2 className="size-4 animate-spin text-primary" /> : <span className="size-4 rounded-full border border-border" />}
            {s}
          </li>
        ))}
      </ul>
      <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-primary-soft">
        <div className="h-full skeleton-shimmer rounded-full" style={{ width: `${((idx + 1) / steps.length) * 100}%` }} />
      </div>
    </div>
  );
}

export const MATCH_STEPS = ["Analisando seu perfil...", "Comparando competências...", "Identificando palavras-chave...", "Calculando compatibilidade...", "Preparando recomendações..."];
export const RESUME_STEPS = ["Lendo seu perfil...", "Mapeando requisitos da vaga...", "Priorizando experiências relevantes...", "Reescrevendo com foco em ATS...", "Revisando factualidade..."];
export const ATS_STEPS = ["Verificando estrutura...", "Comparando palavras-chave...", "Avaliando legibilidade...", "Consolidando pontuação..."];
export const PARSE_STEPS = ["Lendo o documento...", "Identificando seções...", "Extraindo experiências e formação...", "Organizando competências..."];
