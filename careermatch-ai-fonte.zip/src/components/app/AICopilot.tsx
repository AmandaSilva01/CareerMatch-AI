import { useEffect, useRef, useState } from "react";
import { Loader2, SendHorizonal, Sparkles, X } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { askCopilot } from "@/lib/ai/ai.functions";
import { useCopilotContext } from "@/lib/copilot-context";
import { toProfileSnapshot, useProfileBundle } from "@/lib/data/queries";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = ["Melhore meu resumo profissional", "Explique por que meu match está neste valor", "Essa frase está boa para ATS?", "Quais competências devo destacar?"];

export function AICopilot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const ctx = useCopilotContext();
  const bundle = useProfileBundle();
  const ask = useServerFn(askCopilot);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || loading) return;
    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setLoading(true);
    setError(null);
    try {
      const { reply } = await ask({
        data: { messages: next, context: { profile: bundle.profile ? toProfileSnapshot(bundle) : null, job: ctx.job, match: ctx.match, resume: ctx.resume } },
      });
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não conseguimos responder agora. Sua conversa foi preservada.");
    } finally {
      setLoading(false);
    }
  }

  const contextLabel = [ctx.job && `Vaga: ${ctx.job.jobTitle}`, ctx.match && `Match ${ctx.match.score}%`, ctx.resume && "Currículo aberto"].filter(Boolean).join(" · ");

  return (
    <>
      <Button
        variant="ai"
        size="lg"
        onClick={() => setOpen(true)}
        className="fixed bottom-20 right-4 z-40 rounded-full shadow-glow lg:bottom-6 lg:right-6"
        aria-label="Abrir AI Copilot"
      >
        <Sparkles /> Ask AI
      </Button>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent className="flex w-full flex-col gap-0 p-0 sm:max-w-md">
          <SheetHeader className="border-b px-5 py-4">
            <SheetTitle className="flex items-center gap-2 text-base"><Sparkles className="size-4 text-primary" /> AI Copilot</SheetTitle>
            <SheetDescription className="text-xs">{contextLabel || "Abra uma vaga, match ou currículo para respostas contextualizadas."}</SheetDescription>
          </SheetHeader>
          <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
            {messages.length === 0 && (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Sugestões para começar:</p>
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => send(s)} className="block w-full rounded-lg border bg-card px-3 py-2 text-left text-sm transition-colors hover:border-primary-muted hover:bg-accent">
                    {s}
                  </button>
                ))}
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={cn("max-w-[90%] whitespace-pre-wrap rounded-xl px-3.5 py-2.5 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-muted")}>{m.content}</div>
            ))}
            {loading && <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin text-primary" /> Pensando…</div>}
            {error && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive">
                {error} <button className="ml-1 underline" onClick={() => setError(null)}><X className="inline size-3" /></button>
              </div>
            )}
            <div ref={endRef} />
          </div>
          <form
            className="flex items-end gap-2 border-t p-3"
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
          >
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              rows={2}
              placeholder="Pergunte algo sobre seu currículo ou vaga…"
              className="min-h-0 resize-none"
            />
            <Button type="submit" size="icon" disabled={loading || !input.trim()} aria-label="Enviar"><SendHorizonal /></Button>
          </form>
        </SheetContent>
      </Sheet>
    </>
  );
}
