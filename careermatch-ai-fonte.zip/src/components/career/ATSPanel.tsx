import { AlertTriangle, Check, Wrench } from "lucide-react";
import type { ATSResult } from "@/lib/ai/schemas";
import { MatchRing, ScoreBar } from "@/components/career/MatchScore";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

/** ATS score breakdown + issue list. `onFix` sends the issue to the AI improver. */
export function ATSPanel({ result, onFix, fixing }: { result: ATSResult; onFix?: (instruction: string) => void; fixing?: boolean }) {
  const warnings = result.issues.filter((i) => i.type === "warning");
  const oks = result.issues.filter((i) => i.type === "ok");
  return (
    <div className="space-y-5">
      <div className="flex flex-col items-center gap-5 sm:flex-row">
        <div className="flex flex-col items-center">
          <MatchRing score={result.score} size={110} stroke={9} />
          <span className="mt-1 text-xs text-muted-foreground">ATS Score</span>
        </div>
        <div className="w-full flex-1 space-y-2">{result.categories.map((c) => <ScoreBar key={c.key} label={c.label} score={c.score} />)}</div>
      </div>

      {warnings.length > 0 && onFix && (
        <Button className="w-full" variant="brand" disabled={fixing} onClick={() => onFix(`Corrija os seguintes problemas apontados pelo ATS, sem inventar informações:\n${warnings.map((w) => `- ${w.message}${w.fix ? ` (sugestão: ${w.fix})` : ""}`).join("\n")}`)}>
          <Wrench /> Corrigir problemas com IA
        </Button>
      )}

      <div>
        <h4 className="mb-2 text-sm font-semibold">Problemas encontrados</h4>
        {warnings.length === 0 && <p className="text-sm text-subtle">Nenhum problema relevante. ✓</p>}
        <ul className="space-y-2">
          {warnings.map((w, i) => (
            <li key={i} className="rounded-lg border border-warning/30 bg-warning-soft/60 p-3 text-sm">
              <div className="flex gap-2"><AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning" /><div><div>{w.message}</div>{w.fix && <div className="mt-0.5 text-xs text-muted-foreground">Como corrigir: {w.fix}</div>}</div></div>
            </li>
          ))}
        </ul>
      </div>
      {oks.length > 0 && (
        <ul className="space-y-1.5">{oks.map((o, i) => <li key={i} className="flex gap-2 text-sm text-muted-foreground"><Check className="mt-0.5 size-4 shrink-0 text-success" />{o.message}</li>)}</ul>
      )}
      {result.missingKeywords.length > 0 && (
        <div>
          <h4 className="mb-1.5 text-sm font-semibold">Palavras-chave da vaga ausentes</h4>
          <div className="flex flex-wrap gap-1.5">{result.missingKeywords.map((k) => <Badge key={k} variant="warning">{k}</Badge>)}</div>
          <p className="mt-1.5 text-xs text-subtle">Inclua apenas as que forem verdadeiras para o seu perfil.</p>
        </div>
      )}
    </div>
  );
}
