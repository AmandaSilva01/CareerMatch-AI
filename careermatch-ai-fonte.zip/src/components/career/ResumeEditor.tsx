import { Plus, Trash2 } from "lucide-react";
import type { ResumeContent } from "@/lib/ai/schemas";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

type Props = { value: ResumeContent; onChange: (next: ResumeContent) => void };

/** Structured resume editor — pure UI, state owned by the parent. */
export function ResumeEditor({ value: r, onChange }: Props) {
  const set = <K extends keyof ResumeContent>(k: K, v: ResumeContent[K]) => onChange({ ...r, [k]: v });
  const setContact = (k: keyof ResumeContent["contact"], v: string) => onChange({ ...r, contact: { ...r.contact, [k]: v || null } });
  const listField = (k: "skills" | "certifications" | "languages", label: string) => (
    <div className="space-y-1.5">
      <Label>{label} <span className="text-xs font-normal text-subtle">(separe por vírgula)</span></Label>
      <Textarea rows={2} value={r[k].join(", ")} onChange={(e) => set(k, e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} />
    </div>
  );

  return (
    <Accordion type="multiple" defaultValue={["header", "summary", "experience"]} className="space-y-3">
      <Item value="header" title="Dados pessoais">
        <div className="grid gap-3 sm:grid-cols-2">
          <F label="Nome completo"><Input value={r.fullName} onChange={(e) => set("fullName", e.target.value)} /></F>
          <F label="Cargo desejado / título"><Input value={r.headline} onChange={(e) => set("headline", e.target.value)} /></F>
          <F label="Cidade"><Input value={r.contact.city ?? ""} onChange={(e) => setContact("city", e.target.value)} /></F>
          <F label="E-mail"><Input value={r.contact.email ?? ""} onChange={(e) => setContact("email", e.target.value)} /></F>
          <F label="Telefone"><Input value={r.contact.phone ?? ""} onChange={(e) => setContact("phone", e.target.value)} /></F>
          <F label="LinkedIn"><Input value={r.contact.linkedin ?? ""} onChange={(e) => setContact("linkedin", e.target.value)} /></F>
          <F label="GitHub"><Input value={r.contact.github ?? ""} onChange={(e) => setContact("github", e.target.value)} /></F>
          <F label="Portfólio"><Input value={r.contact.portfolio ?? ""} onChange={(e) => setContact("portfolio", e.target.value)} /></F>
        </div>
      </Item>

      <Item value="summary" title="Resumo profissional">
        <Textarea rows={5} value={r.summary} onChange={(e) => set("summary", e.target.value)} />
      </Item>

      <Item value="experience" title={`Experiência (${r.experiences.length})`}>
        <div className="space-y-4">
          {r.experiences.map((e, i) => (
            <div key={i} className="space-y-3 rounded-lg border p-3">
              <div className="grid gap-3 sm:grid-cols-3">
                <F label="Cargo"><Input value={e.role} onChange={(ev) => set("experiences", r.experiences.map((x, j) => (j === i ? { ...x, role: ev.target.value } : x)))} /></F>
                <F label="Empresa"><Input value={e.company} onChange={(ev) => set("experiences", r.experiences.map((x, j) => (j === i ? { ...x, company: ev.target.value } : x)))} /></F>
                <F label="Período"><Input value={e.period} onChange={(ev) => set("experiences", r.experiences.map((x, j) => (j === i ? { ...x, period: ev.target.value } : x)))} /></F>
              </div>
              <F label="Realizações (uma por linha)">
                <Textarea rows={4} value={e.bullets.join("\n")} onChange={(ev) => set("experiences", r.experiences.map((x, j) => (j === i ? { ...x, bullets: ev.target.value.split("\n").filter((l) => l.trim()) } : x)))} />
              </F>
              <div className="flex justify-end"><Button variant="ghost" size="sm" onClick={() => set("experiences", r.experiences.filter((_, j) => j !== i))}><Trash2 /> Remover</Button></div>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={() => set("experiences", [...r.experiences, { company: "", role: "", period: "", bullets: [] }])}><Plus /> Adicionar experiência</Button>
        </div>
      </Item>

      <Item value="education" title={`Formação (${r.education.length})`}>
        <div className="space-y-3">
          {r.education.map((e, i) => (
            <div key={i} className="grid gap-3 rounded-lg border p-3 sm:grid-cols-4">
              <F label="Instituição"><Input value={e.institution} onChange={(ev) => set("education", r.education.map((x, j) => (j === i ? { ...x, institution: ev.target.value } : x)))} /></F>
              <F label="Curso"><Input value={e.course} onChange={(ev) => set("education", r.education.map((x, j) => (j === i ? { ...x, course: ev.target.value } : x)))} /></F>
              <F label="Grau"><Input value={e.degree ?? ""} onChange={(ev) => set("education", r.education.map((x, j) => (j === i ? { ...x, degree: ev.target.value || null } : x)))} /></F>
              <F label="Período"><Input value={e.period} onChange={(ev) => set("education", r.education.map((x, j) => (j === i ? { ...x, period: ev.target.value } : x)))} /></F>
              <div className="flex justify-end sm:col-span-4"><Button variant="ghost" size="sm" onClick={() => set("education", r.education.filter((_, j) => j !== i))}><Trash2 /> Remover</Button></div>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={() => set("education", [...r.education, { institution: "", course: "", degree: null, period: "" }])}><Plus /> Adicionar formação</Button>
        </div>
      </Item>

      <Item value="skills" title="Competências, certificações e idiomas">
        <div className="space-y-4">
          {listField("skills", "Competências")}
          {listField("certifications", "Certificações")}
          {listField("languages", "Idiomas")}
        </div>
      </Item>
    </Accordion>
  );
}

const Item = ({ value, title, children }: { value: string; title: string; children: React.ReactNode }) => (
  <AccordionItem value={value} className="surface px-4">
    <AccordionTrigger className="text-sm font-semibold hover:no-underline">{title}</AccordionTrigger>
    <AccordionContent className="pb-4">{children}</AccordionContent>
  </AccordionItem>
);
const F = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="space-y-1"><Label className="text-xs">{label}</Label>{children}</div>
);
