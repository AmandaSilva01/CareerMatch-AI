import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileText, Plus, MoreHorizontal, Eye, PencilLine, Copy, Type, FileDown, Trash2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { jobsQuery, resumesQuery, useInsert, useRemove, useUpdate, type Resume } from "@/lib/data/queries";
import { exportResumeDocx } from "@/lib/resume-export";
import { PageHeader, EmptyState } from "@/components/career/Primitives";
import { ResumePreview } from "@/components/career/ResumePreview";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/curriculos/")({
  head: () => ({ meta: [{ title: `Meus currículos · ${BRAND.name}` }] }),
  component: ResumeLibrary,
});

function ResumeLibrary() {
  const resumes = useQuery(resumesQuery);
  const jobs = useQuery(jobsQuery);
  const navigate = useNavigate();
  const insert = useInsert("resumes");
  const update = useUpdate("resumes");
  const remove = useRemove("resumes");
  const [preview, setPreview] = useState<Resume | null>(null);
  const [rename, setRename] = useState<Resume | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [del, setDel] = useState<Resume | null>(null);

  return (
    <>
      <PageHeader
        title="Meus currículos"
        description="Uma versão para cada vaga. Todas privadas, todas suas."
        actions={<Button asChild variant="ai"><Link to="/curriculos/novo"><Plus /> Novo currículo</Link></Button>}
      />
      {resumes.isLoading && <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-44 rounded-xl" />)}</div>}
      {!resumes.isLoading && (resumes.data ?? []).length === 0 && (
        <EmptyState
          icon={FileText}
          title="Você ainda não tem currículos"
          description="Crie um currículo base a partir do seu perfil ou gere uma versão otimizada para uma vaga analisada."
          actions={<><Button asChild variant="ai"><Link to="/curriculos/novo"><Sparkles /> Gerar com IA</Link></Button><Button asChild variant="outline"><Link to="/perfil">Completar perfil</Link></Button></>}
        />
      )}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {(resumes.data ?? []).map((r) => {
          const job = jobs.data?.find((j) => j.id === r.job_id);
          return (
            <article key={r.id} className="surface group flex flex-col p-5 transition-shadow hover:shadow-soft">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="truncate font-semibold">{r.name}</h3>
                  <p className="truncate text-xs text-muted-foreground">{job ? `Para: ${job.title}${job.company ? ` · ${job.company}` : ""}` : r.is_base ? "Currículo base" : "Versão livre"}</p>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="Ações"><MoreHorizontal /></Button></DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setPreview(r)}><Eye /> Visualizar</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate({ to: "/curriculos/$resumeId", params: { resumeId: r.id } })}><PencilLine /> Editar</DropdownMenuItem>
                    <DropdownMenuItem onClick={async () => { const row = await insert.mutateAsync({ name: `${r.name} (cópia)`, is_base: false, base_resume_id: r.id, job_id: r.job_id, content: r.content, match_score: r.match_score } as never); toast.success("Currículo duplicado."); navigate({ to: "/curriculos/$resumeId", params: { resumeId: row.id } }); }}><Copy /> Duplicar</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => { setRename(r); setRenameValue(r.name); }}><Type /> Renomear</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => exportResumeDocx(r.content, r.name)}><FileDown /> Exportar DOCX</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDel(r)}><Trash2 /> Excluir</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {r.match_score !== null && <Badge variant="soft">Match {r.match_score}%</Badge>}
                {r.ats_score !== null ? <Badge variant={r.ats_score >= 80 ? "success" : "warning"}>ATS {r.ats_score}</Badge> : <Badge variant="outline">ATS não analisado</Badge>}
              </div>
              <div className="mt-auto flex items-center justify-between pt-4 text-xs text-subtle">
                <span>Atualizado {new Date(r.updated_at).toLocaleDateString("pt-BR")}</span>
                <Button asChild size="sm" variant="ghost"><Link to="/curriculos/$resumeId" params={{ resumeId: r.id }}>Abrir</Link></Button>
              </div>
            </article>
          );
        })}
      </div>

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto p-0">
          <DialogHeader className="px-6 pt-6"><DialogTitle>{preview?.name}</DialogTitle></DialogHeader>
          {preview && <ResumePreview resume={preview.content} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!rename} onOpenChange={(o) => !o && setRename(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Renomear currículo</DialogTitle></DialogHeader>
          <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} autoFocus />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRename(null)}>Cancelar</Button>
            <Button onClick={async () => { if (rename) await update.mutateAsync({ id: rename.id, patch: { name: renameValue } as never }); setRename(null); }}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Excluir “{del?.name}”?</AlertDialogTitle><AlertDialogDescription>Esta ação não pode ser desfeita. Candidaturas ligadas a ele mantêm o histórico, mas sem o arquivo.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={async () => { if (del) { await remove.mutateAsync(del.id); toast.success("Currículo excluído."); } setDel(null); }}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
