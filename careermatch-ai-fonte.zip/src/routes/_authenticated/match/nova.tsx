import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { ClipboardPaste, Link2, FileUp, Search, Sparkles, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { useAnalyzeJob } from "@/lib/flows/analyze-job";
import { fileToParseInput } from "@/lib/resume-import";
import { PageHeader, ErrorNotice, NextStep } from "@/components/career/Primitives";
import { AIProcessing, MATCH_STEPS } from "@/components/career/AIProcessing";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export const Route = createFileRoute("/_authenticated/match/nova")({
  head: () => ({ meta: [{ title: `Analisar vaga · ${BRAND.name}` }] }),
  component: NewAnalysis,
});

const PARSE_STEPS = ["Lendo a descrição da vaga...", "Identificando requisitos e palavras-chave...", "Estruturando cargo, senioridade e modelo de trabalho..."];

function NewAnalysis() {
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [pdfText, setPdfText] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const flow = useAnalyzeJob();
  const navigate = useNavigate();

  async function run(text: string, sourceUrl?: string) {
    if (text.trim().length < 30) {
      toast.error("Cole uma descrição mais completa (mínimo 30 caracteres).");
      return;
    }
    const res = await flow.analyze(text, { sourceUrl: sourceUrl ?? null });
    if (res) navigate({ to: "/match/$matchId", params: { matchId: res.match.id } });
  }

  async function onPdf(file: File | undefined) {
    if (!file) return;
    try {
      const input = await fileToParseInput(file);
      if (input.text) setPdfText(input.text);
      else toast.error("Para PDFs, copie e cole o texto da vaga na aba “Colar descrição”. Arquivos DOCX/TXT são lidos automaticamente.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Arquivo inválido");
    }
  }

  if (flow.stage === "parsing") return <AIProcessing steps={PARSE_STEPS} active title="Interpretando a vaga" />;
  if (flow.stage === "matching") return <AIProcessing steps={MATCH_STEPS} active title="Calculando seu match" />;

  return (
    <>
      <PageHeader eyebrow="Passo 1 de 3" title="Analisar uma vaga" description="Traga a vaga como preferir. A IA estrutura os requisitos e compara com o seu perfil." />

      {!flow.profileReady && (
        <div className="mb-6">
          <NextStep title="Seu perfil ainda está vazio" description="Sem experiências e competências cadastradas, o match não terá base para comparar." to="/perfil" cta="Completar perfil" />
        </div>
      )}
      {flow.stage === "error" && flow.error && <div className="mb-6"><ErrorNotice message={flow.error} onRetry={flow.reset} /></div>}

      <div className="surface p-6">
        <Tabs defaultValue="paste">
          <TabsList className="mb-5 grid w-full grid-cols-2 sm:flex sm:w-auto">
            <TabsTrigger value="paste"><ClipboardPaste className="size-3.5" /> Colar descrição</TabsTrigger>
            <TabsTrigger value="url"><Link2 className="size-3.5" /> Link</TabsTrigger>
            <TabsTrigger value="file"><FileUp className="size-3.5" /> Arquivo</TabsTrigger>
            <TabsTrigger value="search"><Search className="size-3.5" /> Buscar na app</TabsTrigger>
          </TabsList>

          <TabsContent value="paste" className="space-y-4">
            <Textarea rows={14} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Cole aqui a descrição completa da vaga (responsabilidades, requisitos, benefícios...)" />
            <div className="flex items-center justify-between">
              <span className="text-xs text-subtle">{description.length} caracteres</span>
              <Button variant="ai" size="lg" onClick={() => run(description)} disabled={description.trim().length < 30}><Sparkles /> Analisar com IA</Button>
            </div>
          </TabsContent>

          <TabsContent value="url" className="space-y-4">
            <Alert>
              <Link2 className="size-4" />
              <AlertTitle>Importação por link ainda não está ativa</AlertTitle>
              <AlertDescription>
                A maioria dos portais bloqueia leitura automática. Guardamos o link como referência — cole o texto da vaga abaixo para analisar.
              </AlertDescription>
            </Alert>
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." type="url" />
            <Textarea rows={10} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Cole o texto da vaga" />
            <div className="flex justify-end"><Button variant="ai" size="lg" onClick={() => run(description, url || undefined)} disabled={description.trim().length < 30}><Sparkles /> Analisar com IA</Button></div>
          </TabsContent>

          <TabsContent value="file" className="space-y-4">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex w-full flex-col items-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors hover:border-primary-muted hover:bg-accent"
            >
              <FileUp className="mb-2 size-5 text-primary" />
              <span className="font-medium">Selecionar arquivo da vaga</span>
              <span className="mt-1 text-xs text-muted-foreground">DOCX ou TXT são lidos automaticamente</span>
            </button>
            <input ref={fileRef} type="file" accept=".docx,.txt,.pdf" className="sr-only" onChange={(e) => onPdf(e.target.files?.[0])} />
            {pdfText && (
              <>
                <Textarea rows={10} value={pdfText} onChange={(e) => setPdfText(e.target.value)} />
                <div className="flex justify-end"><Button variant="ai" size="lg" onClick={() => run(pdfText)}><Sparkles /> Analisar com IA</Button></div>
              </>
            )}
          </TabsContent>

          <TabsContent value="search">
            <div className="rounded-xl bg-accent p-6 text-center">
              <p className="font-medium">Explore vagas sugeridas dentro da app</p>
              <p className="mt-1 text-sm text-muted-foreground">Escolha uma vaga e analise em um clique.</p>
              <Button asChild className="mt-4"><Link to="/vagas">Ir para Encontrar vagas <ArrowRight /></Link></Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
