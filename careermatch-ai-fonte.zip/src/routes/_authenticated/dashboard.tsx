import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Briefcase, FileText, KanbanSquare, Target, Sparkles, Plus } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { applicationsQuery, jobsQuery, matchesQuery, resumesQuery, useProfile } from "@/lib/data/queries";
import { PageHeader, StatCard, EmptyState, NextStep, Disclaimer } from "@/components/career/Primitives";
import { MatchRing, ScoreBar } from "@/components/career/MatchScore";
import { JobCard } from "@/components/career/JobCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: `Dashboard · ${BRAND.name}` }] }),
  component: Dashboard,
});

function Dashboard() {
  const { data: profile, isLoading: pl } = useProfile();
  const jobs = useQuery(jobsQuery);
  const matches = useQuery(matchesQuery);
  const resumes = useQuery(resumesQuery);
  const apps = useQuery(applicationsQuery);
  const loading = jobs.isLoading || matches.isLoading || resumes.isLoading || apps.isLoading;

  const matchList = matches.data ?? [];
  const compatible = matchList.filter((m) => m.score >= 70).length;
  const avg = matchList.length ? Math.round(matchList.reduce((a, m) => a + m.score, 0) / matchList.length) : null;
  const best = [...matchList].sort((a, b) => b.score - a.score)[0];
  const bestJob = best ? jobs.data?.find((j) => j.id === best.job_id) : undefined;
  const firstName = profile?.full_name?.split(" ")[0];
  const noProfile = !pl && !profile?.onboarding_completed;

  return (
    <>
      <PageHeader
        title={pl ? <Skeleton className="h-8 w-56" /> : <>Olá{firstName ? `, ${firstName}` : ""} 👋</>}
        description="Aqui está o panorama da sua busca. Cada passo abaixo leva você mais perto de uma candidatura forte."
        actions={
          <>
            <Button asChild variant="outline"><Link to="/curriculos/novo"><Plus /> Novo currículo</Link></Button>
            <Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Analisar vaga</Link></Button>
          </>
        }
      />

      {noProfile && (
        <div className="mb-6">
          <NextStep title="Complete seu perfil" description="A IA precisa conhecer suas experiências e competências para calcular matches confiáveis." to="/onboarding" cta="Continuar onboarding" />
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Vagas compatíveis" value={compatible} hint="Match ≥ 70%" icon={Briefcase} loading={loading} />
        <StatCard label="Match médio" value={avg === null ? "—" : `${avg}%`} hint="Compatibilidade com seu perfil" icon={Target} loading={loading} />
        <StatCard label="Currículos criados" value={resumes.data?.length ?? 0} icon={FileText} loading={loading} />
        <StatCard label="Candidaturas" value={apps.data?.length ?? 0} hint="Acompanhadas no Kanban" icon={KanbanSquare} loading={loading} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-5">
        <section className="lg:col-span-3">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Melhor match recente</h2>
            {matchList.length > 0 && <Link to="/match" className="text-sm font-medium text-primary hover:underline">Ver todos</Link>}
          </div>
          {loading ? (
            <Skeleton className="h-64 w-full rounded-xl" />
          ) : best && bestJob ? (
            <div className="surface p-6">
              <div className="flex flex-col gap-6 sm:flex-row">
                <div className="flex flex-col items-center gap-2">
                  <MatchRing score={best.score} />
                  <span className="text-sm font-medium">{best.analysis.label}</span>
                </div>
                <div className="min-w-0 flex-1 space-y-3">
                  <div>
                    <div className="truncate text-lg font-semibold">{bestJob.title}</div>
                    <div className="text-sm text-muted-foreground">{bestJob.company ?? "Empresa não informada"}</div>
                  </div>
                  <div className="space-y-2.5">
                    {best.analysis.categories.slice(0, 4).map((c) => <ScoreBar key={c.key} label={c.label} score={c.score} />)}
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button asChild size="sm"><Link to="/match/$matchId" params={{ matchId: best.id }}>Ver análise completa <ArrowRight /></Link></Button>
                    <Button asChild size="sm" variant="soft"><Link to="/curriculos/novo" search={{ matchId: best.id }}><Sparkles /> Otimizar currículo</Link></Button>
                  </div>
                </div>
              </div>
              <div className="mt-4"><Disclaimer /></div>
            </div>
          ) : (
            <EmptyState
              icon={Target}
              title="Nenhuma vaga analisada ainda"
              description="Cole a descrição de uma vaga e a IA mostrará sua compatibilidade, os pontos fortes e o que está faltando."
              actions={<Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Analisar minha primeira vaga</Link></Button>}
            />
          )}
        </section>

        <section className="lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Vagas recentes</h2>
            <Link to="/vagas" className="text-sm font-medium text-primary hover:underline">Encontrar vagas</Link>
          </div>
          <div className="space-y-3">
            {loading && [0, 1].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
            {!loading && (jobs.data ?? []).slice(0, 3).map((j) => (
              <JobCard key={j.id} job={j} match={matchList.find((m) => m.job_id === j.id)} compact />
            ))}
            {!loading && (jobs.data ?? []).length === 0 && (
              <div className="surface p-5 text-sm text-muted-foreground">
                Nenhuma vaga salva. Explore sugestões em <Link to="/vagas" className="font-medium text-primary">Encontrar vagas</Link>.
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
