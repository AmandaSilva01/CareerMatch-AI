/**
 * AI Provider layer — the only place that knows which LLM vendor is used.
 * Swap the model/provider here without touching the rest of the product.
 */
import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output } from "ai";
import type { z } from "zod";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
export const DEFAULT_MODEL = "openai/gpt-6-astra";

const RUN_ID_HEADER = "X-Lovable-AIG-Run-ID";

/** Captures the gateway run id from the first response and resends it on follow-ups. */
function createRunIdFetch(initialRunId?: string | null) {
  let runId = initialRunId ?? null;
  const wrapped: typeof fetch = async (input, init) => {
    const headers = new Headers(init?.headers);
    if (runId) headers.set(RUN_ID_HEADER, runId);
    const res = await fetch(input, { ...init, headers });
    const got = res.headers.get(RUN_ID_HEADER);
    if (got) runId = got;
    return res;
  };
  return { fetch: wrapped, getRunId: () => runId };
}

export class AIConfigError extends Error {}

function getProvider() {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new AIConfigError("LOVABLE_API_KEY não configurada.");
  const runIdFetch = createRunIdFetch();
  return createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey: key,
    headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });
}

export const FACTUALITY_RULES = `REGRAS DE FACTUALIDADE (obrigatórias):
- Nunca invente informações sobre o candidato: experiências, resultados, certificações, competências, cargos, empresas, números, datas.
- Nunca transforme uma habilidade ausente em uma habilidade existente.
- Nunca altere fatos para o candidato parecer mais qualificado. Nunca insira palavras-chave falsas.
- Nunca afirme que o candidato será contratado. O Match Score é apenas compatibilidade estimada entre perfil e requisitos identificados na vaga, nunca probabilidade de contratação.
- Quando uma informação estiver ausente, marque como "Não identificado no perfil".
- Sempre diferencie: informação encontrada, inferência e recomendação.
- Faça matching semântico (ex.: "análise de indicadores" ≈ "monitoramento de KPIs"), não apenas por palavras exatas.
- Responda sempre em português do Brasil.`;

type FilePart = { type: "file"; data: string; mediaType: string; filename: string };

export interface StructuredCallOptions<T extends z.ZodTypeAny> {
  system: string;
  prompt: string;
  schema: T;
  /** Optional attached file (e.g. a PDF resume), base64 encoded. */
  file?: { base64: string; mediaType: string; filename: string } | undefined;
  effort?: "low" | "medium" | "high" | undefined;
}

/** One-shot structured generation. Streams internally (required by the gateway) and returns the parsed object. */
export async function generateStructured<T extends z.ZodTypeAny>(opts: StructuredCallOptions<T>): Promise<z.infer<T>> {
  const provider = getProvider();
  const userContent: Array<{ type: "text"; text: string } | FilePart> = [{ type: "text", text: opts.prompt }];
  if (opts.file) {
    userContent.push({ type: "file", data: opts.file.base64, mediaType: opts.file.mediaType, filename: opts.file.filename });
  }
  const result = streamText({
    model: provider.responses(DEFAULT_MODEL),
    system: opts.system,
    messages: [{ role: "user", content: userContent }],
    output: Output.object({ schema: opts.schema }),
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: opts.effort ?? "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  const output = await result.output;
  if (!output) throw new Error("A IA não retornou um resultado válido.");
  return output as z.infer<T>;
}

/** Plain text generation for the copilot (multi-turn, stateless). */
export async function generateChat(opts: {
  system: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
}): Promise<string> {
  const provider = getProvider();
  const result = streamText({
    model: provider.responses(DEFAULT_MODEL),
    system: opts.system,
    messages: opts.messages,
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  const text = await result.text;
  return text.trim() || "Não consegui formular uma resposta agora. Tente reformular a pergunta.";
}

/** Maps gateway errors into human, safe messages. */
export function humanizeAIError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (err instanceof AIConfigError) return "A IA ainda não está configurada neste ambiente.";
  if (/402|credits|insufficient/i.test(msg)) return "Os créditos de IA acabaram. Adicione créditos ao workspace para continuar.";
  if (/429|rate limit/i.test(msg)) return "Muitas solicitações no momento. Aguarde alguns instantes e tente novamente.";
  if (/403|denied|refus/i.test(msg)) return "A solicitação foi recusada pelo provedor de IA.";
  return "Não conseguimos concluir a análise agora. Suas informações foram preservadas. Tente novamente em alguns instantes.";
}
