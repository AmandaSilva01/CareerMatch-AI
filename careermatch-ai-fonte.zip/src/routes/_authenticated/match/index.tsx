import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, Target, ArrowRight } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { jobsQuery, matchesQuery } from "@/lib/data/queries";
import { PageHeader, EmptyState, Disclaimer } from "@/components/career/Primitives";
import { MatchRing } from "@/components/career/MatchScore";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/match/")({
  head: () => ({ meta: [{ title: `Match de Vagas · ${BRAND.name}` }] }),
  component: MatchList,
});

function MatchList() {
  const matches = useQuery(matchesQuery);
  const jobs = useQuery(jobsQuery);
  const loading = matches.isLoading || jobs.isLoading;
  const list = [...(matches.data ?? [])].sort((a, b) => b.score - a.score);

  return (
    <>
      <PageHeader
        title="Match de Vagas"
        description="Cada análise mostra o quanto seu perfil se conecta à vaga — e o que fazer a respeito."
        actions={<Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Analisar nova vaga</Link></Button>}
      />
      {loading && <div className="grid gap-4 md:grid-cols-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}</div>}
      {!loading && list.length === 0 && (
        <EmptyState
          icon={Target}
          title="Você ainda não analisou nenhuma vaga"
          description="Cole a descrição de uma vaga. Em segundos você verá compatibilidade, pontos fortes e lacunas — com explicação."
          actions={<Button asChild variant="ai"><Link to="/match/nova"><Sparkles /> Analisar minha primeira vaga</Link></Button>}
        />
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {list.map((m) => {
          const job = jobs.data?.find((j) => j.id === m.job_id);
          return (
            <Link key={m.id} to="/match/$matchId" params={{ matchId: m.id }} className="surface group flex gap-5 p-5 transition-shadow hover:shadow-soft">
              <MatchRing score={m.score} size={88} stroke={8} animate={false} />
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold group-hover:text-primary">{job?.title ?? "Vaga"}</div>
                <div className="text-sm text-muted-foreground">{job?.company ?? "Empresa não informada"}</div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <Badge variant="soft">{m.analysis.label}</Badge>
                  <Badge variant="outline">{m.analysis.matchedSkills.length} competências ✓</Badge>
                  <Badge variant="outline">{m.analysis.gaps.length} pontos ⚠</Badge>
                </div>
                <div className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-primary">Ver análise <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" /></div>
              </div>
            </Link>
          );
        })}
      </div>
      {list.length > 0 && <div className="mt-6"><Disclaimer /></div>}
    </>
  );
}
