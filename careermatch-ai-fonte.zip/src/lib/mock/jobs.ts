/**
 * MOCK LAYER — curated sample job postings shown in "Encontrar vagas" until a real job-board
 * integration is connected. They are clearly labelled as examples in the UI and never presented
 * as live listings. Replace `listSuggestedJobs` with a real provider (API/scraper) to go live.
 */
export type SuggestedJob = {
  id: string;
  title: string;
  company: string;
  location: string;
  workModel: "Remoto" | "Híbrido" | "Presencial";
  seniority: "Estágio" | "Júnior" | "Pleno" | "Sênior" | "Liderança";
  area: string;
  salaryRange: string | null;
  description: string;
};

const JOBS: SuggestedJob[] = [
  {
    id: "mock-analista-dados-pleno",
    title: "Analista de Dados Pleno",
    company: "Nubank (exemplo)",
    location: "São Paulo, SP",
    workModel: "Híbrido",
    seniority: "Pleno",
    area: "Dados",
    salaryRange: "R$ 9.000 – R$ 12.000",
    description: `Buscamos Analista de Dados Pleno para atuar no time de Crédito.
Responsabilidades: construir dashboards e monitorar KPIs de negócio; desenvolver análises exploratórias para apoiar decisões; criar e manter pipelines de dados em SQL e Python; apresentar insights para stakeholders de produto e risco.
Requisitos obrigatórios: 3+ anos em análise de dados; SQL avançado; Python (pandas); ferramentas de BI (Looker, Tableau ou Power BI); experiência com testes A/B e métricas de produto.
Desejáveis: dbt, Airflow, conhecimento de modelagem estatística, inglês intermediário.
Soft skills: comunicação com áreas de negócio, autonomia, pensamento analítico.`,
  },
  {
    id: "mock-dev-frontend-senior",
    title: "Desenvolvedor(a) Front-end Sênior",
    company: "iFood (exemplo)",
    location: "Remoto — Brasil",
    workModel: "Remoto",
    seniority: "Sênior",
    area: "Tecnologia",
    salaryRange: null,
    description: `Procuramos pessoa desenvolvedora front-end sênior para o time de Experiência do Consumidor.
Responsabilidades: liderar tecnicamente a evolução de aplicações React/TypeScript; garantir performance, acessibilidade e qualidade; colaborar com design e produto; mentorar pessoas desenvolvedoras.
Requisitos: 5+ anos com JavaScript/TypeScript; React avançado; testes (Jest, Testing Library, Cypress); design systems; CI/CD; GraphQL ou REST.
Desejáveis: Next.js, micro-frontends, observabilidade (Datadog), inglês avançado.
Soft skills: liderança técnica, comunicação clara, colaboração.`,
  },
  {
    id: "mock-product-manager-pleno",
    title: "Product Manager Pleno",
    company: "Stone (exemplo)",
    location: "Rio de Janeiro, RJ",
    workModel: "Híbrido",
    seniority: "Pleno",
    area: "Produto",
    salaryRange: "R$ 11.000 – R$ 15.000",
    description: `Product Manager para produtos de pagamento B2B.
Responsabilidades: definir roadmap e priorização baseada em dados; conduzir discovery com clientes; escrever PRDs e histórias; acompanhar métricas de adoção e retenção; alinhar stakeholders de negócio, tecnologia e design.
Requisitos: 3+ anos como PM; experiência com discovery e métricas de produto; SQL básico; metodologias ágeis; comunicação executiva.
Desejáveis: experiência em fintech, inglês avançado, familiaridade com Amplitude/Mixpanel.`,
  },
  {
    id: "mock-marketing-growth",
    title: "Analista de Growth Marketing",
    company: "Hotmart (exemplo)",
    location: "Belo Horizonte, MG",
    workModel: "Híbrido",
    seniority: "Júnior",
    area: "Marketing",
    salaryRange: "R$ 4.500 – R$ 6.000",
    description: `Analista de Growth para aquisição paga e CRM.
Responsabilidades: gerenciar campanhas em Meta Ads e Google Ads; criar experimentos de conversão; analisar funis e reportar resultados; operar fluxos de e-mail e automações.
Requisitos: 1+ ano com mídia paga; Google Analytics 4; Excel/Sheets avançado; noções de copywriting.
Desejáveis: HubSpot ou RD Station, SQL básico, inglês intermediário.`,
  },
  {
    id: "mock-analista-financeiro",
    title: "Analista Financeiro Sênior (FP&A)",
    company: "Ambev (exemplo)",
    location: "São Paulo, SP",
    workModel: "Presencial",
    seniority: "Sênior",
    area: "Finanças",
    salaryRange: null,
    description: `Analista Sênior de FP&A para planejamento e análise de resultados.
Responsabilidades: elaborar orçamento e forecast; analisar variações de P&L; construir modelos financeiros; apoiar decisões de investimento; apresentar resultados à liderança.
Requisitos: 5+ anos em FP&A ou controladoria; Excel avançado; Power BI; contabilidade gerencial; inglês avançado.
Desejáveis: SAP, Python ou SQL para análise, certificação CFA nível I.`,
  },
  {
    id: "mock-cs-manager",
    title: "Customer Success Manager",
    company: "RD Station (exemplo)",
    location: "Florianópolis, SC",
    workModel: "Remoto",
    seniority: "Pleno",
    area: "Customer Success",
    salaryRange: "R$ 6.000 – R$ 8.500",
    description: `CSM para carteira de clientes SMB em SaaS.
Responsabilidades: conduzir onboarding e adoção; monitorar health score e churn; realizar QBRs; identificar oportunidades de expansão; atuar com produto para levar feedback.
Requisitos: 2+ anos em CS ou Account Management em SaaS; domínio de CRM (HubSpot/Salesforce); comunicação e negociação; análise de métricas (NPS, churn, NRR).
Desejáveis: inglês intermediário, experiência com Gainsight.`,
  },
  {
    id: "mock-analista-rh",
    title: "Analista de Recrutamento e Seleção",
    company: "Magazine Luiza (exemplo)",
    location: "São Paulo, SP",
    workModel: "Híbrido",
    seniority: "Pleno",
    area: "RH",
    salaryRange: "R$ 5.000 – R$ 7.000",
    description: `Analista de R&S para vagas de tecnologia.
Responsabilidades: conduzir processos seletivos ponta a ponta; hunting ativo no LinkedIn Recruiter; entrevistas por competências; gestão de indicadores (time to hire, funil); employer branding.
Requisitos: 2+ anos em recrutamento tech; ATS (Gupy, Greenhouse); entrevista por competências; Excel intermediário.
Desejáveis: inglês intermediário, psicologia ou RH.`,
  },
  {
    id: "mock-eng-dados-senior",
    title: "Engenheiro(a) de Dados Sênior",
    company: "Mercado Livre (exemplo)",
    location: "Remoto — LATAM",
    workModel: "Remoto",
    seniority: "Sênior",
    area: "Engenharia",
    salaryRange: null,
    description: `Engenharia de Dados para plataforma de analytics em escala.
Responsabilidades: projetar pipelines batch e streaming; modelar data lakehouse; garantir qualidade e governança; otimizar custo em cloud.
Requisitos: 5+ anos em engenharia de dados; Python e SQL avançados; Spark; Airflow; AWS ou GCP; modelagem dimensional; CI/CD.
Desejáveis: Kafka, dbt, Terraform, inglês avançado.`,
  },
];

export function listSuggestedJobs(): SuggestedJob[] {
  return JOBS;
}
export function getSuggestedJob(id: string) {
  return JOBS.find((j) => j.id === id) ?? null;
}
