import { Link } from "@tanstack/react-router";
import { Building2, MapPin, Sparkles, ArrowUpRight } from "lucide-react";
import type { Job, Match } from "@/lib/data/queries";
import { MatchPill } from "@/components/career/MatchScore";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function JobCard({ job, match, compact }: { job: Job; match?: Match | undefined; compact?: boolean }) {
  const p = job.parsed_data;
  const matched = match?.analysis.matchedSkills.length ?? 0;
  return (
    <article className={cn("surface flex flex-col gap-3 p-5 transition-shadow hover:shadow-soft", compact && "p-4")}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate font-semibold">{job.title}</h3>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Building2 className="size-3" /> {job.company ?? "Empresa não informada"}</span>
            {(job.location || job.work_model) && <span className="inline-flex items-center gap-1"><MapPin className="size-3" /> {[job.location, job.work_model].filter(Boolean).join(" · ")}</span>}
          </div>
        </div>
        {match ? <MatchPill score={match.score} /> : <Badge variant="outline">Sem match</Badge>}
      </div>
      {!compact && p && (
        <div className="flex flex-wrap gap-1.5">
          {p.technicalSkills.slice(0, 5).map((s) => <Badge key={s} variant="secondary">{s}</Badge>)}
          {job.seniority && <Badge variant="outline">{job.seniority}</Badge>}
        </div>
      )}
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">
          {match ? `${matched} competência${matched === 1 ? "" : "s"} compatíve${matched === 1 ? "l" : "is"}` : "Analise para ver a compatibilidade"}
        </span>
        <div className="flex gap-1.5">
          <Button asChild size="sm" variant="ghost"><Link to="/vagas/$jobId" params={{ jobId: job.id }}>Ver vaga <ArrowUpRight /></Link></Button>
          {match ? (
            <Button asChild size="sm" variant="soft"><Link to="/curriculos/novo" search={{ matchId: match.id }}><Sparkles /> Gerar currículo</Link></Button>
          ) : (
            <Button asChild size="sm" variant="soft"><Link to="/vagas/$jobId" params={{ jobId: job.id }}><Sparkles /> Calcular match</Link></Button>
          )}
        </div>
      </div>
    </article>
  );
}
