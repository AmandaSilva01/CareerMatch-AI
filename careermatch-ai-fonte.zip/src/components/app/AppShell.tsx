import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  LayoutDashboard, UserRound, FileText, Search, Target, KanbanSquare, BarChart3, Settings, LogOut, Menu, Sparkles, CreditCard, ChevronsUpDown, Command as CommandIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useProfile } from "@/lib/data/queries";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/career/Logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { AICopilot } from "@/components/app/AICopilot";

export const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/perfil", label: "Meu Perfil", icon: UserRound },
  { to: "/curriculos", label: "Currículos", icon: FileText },
  { to: "/vagas", label: "Encontrar Vagas", icon: Search },
  { to: "/match", label: "Match de Vagas", icon: Target },
  { to: "/candidaturas", label: "Candidaturas", icon: KanbanSquare },
  { to: "/insights", label: "Insights", icon: BarChart3 },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
] as const;

export type NavPath = (typeof NAV)[number]["to"];

const MOBILE_NAV: NavPath[] = ["/dashboard", "/vagas", "/match", "/curriculos", "/candidaturas"];

export function AppShell({ children }: { children: ReactNode }) {
  const [cmdOpen, setCmdOpen] = useState(false);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmdOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar lg:flex">
        <SidebarContent onCommand={() => setCmdOpen(true)} />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur lg:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Abrir menu"><Menu /></Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <SheetTitle className="sr-only">Navegação</SheetTitle>
              <SidebarContent onCommand={() => setCmdOpen(true)} />
            </SheetContent>
          </Sheet>
          <Logo to="/dashboard" />
        </header>

        <main className="flex-1 px-4 py-6 pb-24 sm:px-6 lg:px-10 lg:py-8 lg:pb-8">
          <div className="mx-auto w-full max-w-6xl animate-fade-up">{children}</div>
        </main>

        <MobileNav />
      </div>

      <AICopilot />
      <CommandPalette open={cmdOpen} onOpenChange={setCmdOpen} />
    </div>
  );
}

function SidebarContent({ onCommand }: { onCommand: () => void }) {
  const { data: profile } = useProfile();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const name = profile?.full_name ?? "Sua conta";
  const initials = name.split(" ").slice(0, 2).map((p) => p[0]).join("").toUpperCase();

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center justify-between px-5">
        <Logo to="/dashboard" />
      </div>
      <button
        onClick={onCommand}
        className="mx-3 mb-3 flex items-center gap-2 rounded-lg border bg-card px-3 py-2 text-left text-sm text-muted-foreground transition-colors hover:bg-accent"
      >
        <CommandIcon className="size-3.5" /> Buscar ou ir para…
        <kbd className="ml-auto rounded border bg-muted px-1.5 py-0.5 text-[10px] font-medium text-subtle">⌘K</kbd>
      </button>
      <nav className="flex-1 space-y-0.5 px-3" aria-label="Principal">
        {NAV.map((item) => {
          const active = pathname === item.to || pathname.startsWith(item.to + "/");
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active ? "bg-primary-soft text-primary" : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground",
              )}
            >
              <item.icon className="size-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t p-3">
        <Link to="/plano" className="mb-2 flex items-center justify-between rounded-lg bg-accent px-3 py-2 text-xs transition-colors hover:bg-primary-soft">
          <span className="flex items-center gap-1.5 font-medium text-accent-foreground"><Sparkles className="size-3.5 text-primary" /> Plano {profile?.plan === "pro" ? "Pro" : "Free"}</span>
          {profile?.plan !== "pro" && <span className="font-medium text-primary">Upgrade</span>}
        </Link>
        <Link to="/perfil" className="flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left transition-colors hover:bg-sidebar-accent">
          <Avatar className="size-8"><AvatarFallback className="bg-primary-soft text-xs font-semibold text-primary">{initials || "?"}</AvatarFallback></Avatar>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium">{name}</div>
            <div className="truncate text-xs text-muted-foreground">Ver meu perfil</div>
          </div>
        </Link>
      </div>
    </div>
  );
}

function MobileNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-background/95 backdrop-blur lg:hidden" aria-label="Navegação inferior">
      {NAV.filter((n) => MOBILE_NAV.includes(n.to)).map((item) => {
        const active = pathname.startsWith(item.to);
        return (
          <Link key={item.to} to={item.to} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", active ? "text-primary" : "text-muted-foreground")}>
            <item.icon className="size-5" />
            {item.label.split(" ")[0]}
          </Link>
        );
      })}
    </nav>
  );
}

function CommandPalette({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const navigate = useNavigate();
  const go = (to: string) => {
    onOpenChange(false);
    navigate({ to });
  };
  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="O que você quer fazer?" />
      <CommandList>
        <CommandEmpty>Nada encontrado.</CommandEmpty>
        <CommandGroup heading="Ações">
          <CommandItem onSelect={() => go("/match/nova")}><Target /> Analisar uma vaga <Badge variant="soft" className="ml-auto">IA</Badge></CommandItem>
          <CommandItem onSelect={() => go("/curriculos/novo")}><FileText /> Criar currículo</CommandItem>
          <CommandItem onSelect={() => go("/perfil?import=1")}><UserRound /> Importar currículo para o perfil</CommandItem>
        </CommandGroup>
        <CommandGroup heading="Ir para">
          {NAV.map((n) => (
            <CommandItem key={n.to} onSelect={() => go(n.to)}><n.icon /> {n.label}</CommandItem>
          ))}
          <CommandItem onSelect={() => go("/plano")}><CreditCard /> Plano</CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
