import type { ResumeContent } from "@/lib/ai/schemas";
import { cn } from "@/lib/utils";

/**
 * ATS-friendly resume template: plain text hierarchy, no tables/graphics/skill bars.
 * Rendered on screen and used as the print (PDF) source.
 */
export function ResumePreview({ resume, className, compact }: { resume: ResumeContent; className?: string; compact?: boolean }) {
  const contact = [resume.contact.city, resume.contact.email, resume.contact.phone, resume.contact.linkedin, resume.contact.github, resume.contact.portfolio].filter(Boolean);
  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <section className={compact ? "mt-3" : "mt-5"}>
      <h2 className="border-b border-foreground/80 pb-1 text-[11px] font-bold uppercase tracking-[0.14em]">{title}</h2>
      <div className="mt-2 space-y-2">{children}</div>
    </section>
  );
  return (
    <article
      id="resume-print"
      className={cn("bg-card px-10 py-9 font-sans text-[12.5px] leading-relaxed text-foreground", compact && "px-6 py-5 text-[11px]", className)}
      style={{ fontFamily: "Inter, Arial, Helvetica, sans-serif" }}
    >
      <header>
        <h1 className="text-[22px] font-bold uppercase tracking-tight">{resume.fullName || "Nome completo"}</h1>
        {resume.headline && <p className="mt-0.5 text-[13px] font-medium">{resume.headline}</p>}
        {contact.length > 0 && <p className="mt-1 text-[11.5px] text-muted-foreground">{contact.join(" | ")}</p>}
      </header>

      {resume.summary && (
        <Section title="Resumo profissional">
          <p className="whitespace-pre-line">{resume.summary}</p>
        </Section>
      )}

      {resume.experiences.length > 0 && (
        <Section title="Experiência profissional">
          {resume.experiences.map((e, i) => (
            <div key={i} className="break-inside-avoid">
              <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                <span className="font-semibold">{e.company}</span>
                <span className="text-[11px] text-muted-foreground">{e.period}</span>
              </div>
              <div className="font-medium">{e.role}</div>
              {e.bullets.length > 0 && (
                <ul className="mt-1 list-disc space-y-0.5 pl-4">
                  {e.bullets.map((b, j) => <li key={j}>{b}</li>)}
                </ul>
              )}
            </div>
          ))}
        </Section>
      )}

      {resume.education.length > 0 && (
        <Section title="Formação acadêmica">
          {resume.education.map((e, i) => (
            <div key={i} className="flex flex-wrap items-baseline justify-between gap-x-3">
              <div>
                <span className="font-semibold">{e.course}</span>
                {e.degree ? <span> — {e.degree}</span> : null}
                <div className="text-muted-foreground">{e.institution}</div>
              </div>
              <span className="text-[11px] text-muted-foreground">{e.period}</span>
            </div>
          ))}
        </Section>
      )}

      {resume.skills.length > 0 && (
        <Section title="Competências">
          <p>{resume.skills.join(" · ")}</p>
        </Section>
      )}
      {resume.certifications.length > 0 && (
        <Section title="Certificações">
          <ul className="list-disc pl-4">{resume.certifications.map((c, i) => <li key={i}>{c}</li>)}</ul>
        </Section>
      )}
      {resume.languages.length > 0 && (
        <Section title="Idiomas">
          <p>{resume.languages.join(" · ")}</p>
        </Section>
      )}
    </article>
  );
}
