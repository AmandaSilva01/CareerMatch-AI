/** Tiny store so any page can hand the AI Copilot the job/match/resume currently on screen. */
import { useEffect, useSyncExternalStore } from "react";
import type { MatchResult, ParsedJob, ResumeContent } from "@/lib/ai/schemas";

export type CopilotContext = { job: ParsedJob | null; match: MatchResult | null; resume: ResumeContent | null };

let state: CopilotContext = { job: null, match: null, resume: null };
const listeners = new Set<() => void>();

function set(patch: Partial<CopilotContext>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function useCopilotContext() {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
    () => state,
  );
}

/** Register page context while mounted; cleared on unmount. */
export function useProvideCopilotContext(ctx: Partial<CopilotContext>) {
  const job = ctx.job ?? null;
  const match = ctx.match ?? null;
  const resume = ctx.resume ?? null;
  useEffect(() => {
    set({ job, match, resume });
    return () => set({ job: null, match: null, resume: null });
  }, [job, match, resume]);
}
