import { Link } from "@tanstack/react-router";
import { Check, AlertTriangle, Lightbulb, Sparkles, Info } from "lucide-react";
import type { MatchResult } from "@/lib/ai/schemas";
import { MatchRing, ScoreBar } from "@/components/career/MatchScore";
import { Disclaimer, NextStep, AIBadge } from "@/components/career/Primitives";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const KIND_LABEL = { found: "Não identificado no perfil", inference: "Inferência da IA", recommendation: "Recomendação" } as const;

/** Full explained match: ring + categories + why/what's missing/what to highlight. */
export function MatchAnalysis({ match, matchId, jobTitle }: { match: MatchResult; matchId?: string | undefined; jobTitle?: string | undefined }) {
  return (
    <div className="space-y-6">
      <section className="surface p-6">
        <div className="flex flex-col gap-6 md:flex-row md:items-start">
          <div className="flex flex-col items-center gap-1 md:w-48">
            <MatchRing score={match.score} size={150} />
            <div className="mt-1 text-center">
              <div className="font-semibold">{match.label}</div>
              <div className="text-xs text-muted-foreground">Compatibilidade com seu perfil</div>
            </div>
          </div>
          <div className="flex-1 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Por categoria</h3>
              <AIBadge>Explicado pela IA</AIBadge>
            </div>
            {match.categories.map((c) => (
              <Tooltip key={c.key}>
                <TooltipTrigger asChild>
                  <div className="cursor-help"><ScoreBar label={c.label} score={c.score} /></div>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs text-xs">{c.rationale}</TooltipContent>
              </Tooltip>
            ))}
          </div>
        </div>
        <div className="mt-5 border-t pt-4"><Disclaimer>{match.disclaimer}</Disclaimer></div>
      </section>

      {matchId && (
        <NextStep
          title="Otimizar meu currículo para esta vaga"
          description="A IA reorganiza e destaca o que você já tem — sem inventar nada — para aumentar a relevância."
          to={`/curriculos/novo?matchId=${matchId}`}
          cta="Otimizar currículo"
        />
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Panel icon={Check} tone="success" title={`Você combina com ${jobTitle ? "esta vaga" : "a vaga"} porque`}>
          {match.strengths.length === 0 && <Empty />}
          <ul className="space-y-2">{match.strengths.map((s, i) => <li key={i} className="flex gap-2 text-sm"><Check className="mt-0.5 size-4 shrink-0 text-success" />{s}</li>)}</ul>
          {match.matchedSkills.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">{match.matchedSkills.map((s) => <Badge key={s} variant="success">{s}</Badge>)}</div>
          )}
        </Panel>
        <Panel icon={AlertTriangle} tone="warning" title="O que está faltando">
          {match.gaps.length === 0 && <Empty text="Nenhuma lacuna relevante identificada." />}
          <ul className="space-y-2.5">
            {match.gaps.map((g, i) => (
              <li key={i} className="text-sm">
                <div className="flex items-start gap-2">
                  <AlertTriangle className={cn("mt-0.5 size-4 shrink-0", g.severity === "high" ? "text-brand" : "text-warning")} />
                  <div>
                    <div className="font-medium">{g.item}</div>
                    <div className="text-muted-foreground">{g.note}</div>
                    <span className="mt-1 inline-flex items-center gap-1 text-[11px] text-subtle"><Info className="size-3" /> {KIND_LABEL[g.kind]}</span>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel icon={Lightbulb} tone="primary" title="O que você pode destacar melhor">
          {match.highlightSuggestions.length === 0 && <Empty />}
          <ul className="space-y-2.5">
            {match.highlightSuggestions.map((h, i) => (
              <li key={i} className="text-sm">
                <div className="flex items-start gap-2"><Sparkles className="mt-0.5 size-4 shrink-0 text-primary" /><div><div className="font-medium">{h.title}</div><div className="text-muted-foreground">{h.detail}</div></div></div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
      {matchId && (
        <p className="text-center text-sm text-muted-foreground">
          Prefere ver a vaga primeiro? <Link to="/match" className="font-medium text-primary hover:underline">Voltar para meus matches</Link>
        </p>
      )}
    </div>
  );
}

function Panel({ icon: Icon, tone, title, children }: { icon: typeof Check; tone: "success" | "warning" | "primary"; title: string; children: React.ReactNode }) {
  const toneCls = { success: "bg-success-soft text-success", warning: "bg-warning-soft text-warning", primary: "bg-primary-soft text-primary" }[tone];
  return (
    <section className="surface p-5">
      <div className="mb-3 flex items-center gap-2">
        <span className={cn("rounded-lg p-1.5", toneCls)}><Icon className="size-4" /></span>
        <h3 className="text-sm font-semibold">{title}</h3>
      </div>
      {children}
    </section>
  );
}
const Empty = ({ text = "Não identificado." }: { text?: string }) => <p className="text-sm text-subtle">{text}</p>;
