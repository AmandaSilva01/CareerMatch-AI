import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Sparkles, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export function PageHeader({ title, description, actions, eyebrow }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="space-y-1.5">
        {eyebrow && <div className="text-xs font-medium uppercase tracking-wider text-primary">{eyebrow}</div>}
        <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">{title}</h1>
        {description && <p className="max-w-2xl text-sm text-muted-foreground md:text-[15px]">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function StatCard({ label, value, hint, icon: Icon, loading }: { label: string; value: ReactNode; hint?: string; icon: LucideIcon; loading?: boolean }) {
  return (
    <div className="surface p-5 transition-shadow hover:shadow-soft">
      <div className="flex items-start justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className="rounded-lg bg-primary-soft p-1.5 text-primary">
          <Icon className="size-4" />
        </span>
      </div>
      {loading ? <Skeleton className="mt-3 h-8 w-16" /> : <div className="mt-2 text-3xl font-semibold tracking-tight tabular-nums">{value}</div>}
      {hint && <div className="mt-1 text-xs text-subtle">{hint}</div>}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, description, actions, className }: { icon: LucideIcon; title: string; description: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <div className={cn("surface flex flex-col items-center px-6 py-14 text-center", className)}>
      <div className="mb-4 rounded-2xl bg-primary-soft p-3 text-primary">
        <Icon className="size-6" />
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1.5 max-w-sm text-sm text-muted-foreground">{description}</p>
      {actions && <div className="mt-6 flex flex-wrap justify-center gap-2">{actions}</div>}
    </div>
  );
}

export function AIBadge({ children = "IA", className }: { children?: ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full bg-primary-soft px-2 py-0.5 text-[11px] font-medium text-accent-foreground", className)}>
      <Sparkles className="size-3" /> {children}
    </span>
  );
}

export function Disclaimer({ children }: { children?: ReactNode }) {
  return (
    <p className="text-xs leading-relaxed text-subtle">
      {children ?? "O Match Score representa a compatibilidade estimada entre as informações do seu perfil e os requisitos identificados na vaga. Ele não indica probabilidade de contratação."}
    </p>
  );
}

export function NextStep({ title, description, to, cta, icon: Icon = Sparkles, onClick }: { title: string; description: string; to?: string; cta: string; icon?: LucideIcon; onClick?: () => void }) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-primary-muted/50 bg-accent p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 rounded-lg bg-card p-1.5 text-primary shadow-card"><Icon className="size-4" /></span>
        <div>
          <div className="text-xs font-medium uppercase tracking-wider text-primary">Próximo passo</div>
          <div className="text-sm font-semibold">{title}</div>
          <div className="text-sm text-muted-foreground">{description}</div>
        </div>
      </div>
      {to ? (
        <Button asChild><Link to={to}>{cta}</Link></Button>
      ) : (
        <Button onClick={onClick}>{cta}</Button>
      )}
    </div>
  );
}

export function ErrorNotice({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-destructive/20 bg-destructive/5 p-4 text-sm">
      <p className="font-medium text-foreground">Não conseguimos concluir agora.</p>
      <p className="mt-0.5 text-muted-foreground">{message}</p>
      {onRetry && <Button size="sm" variant="outline" className="mt-3" onClick={onRetry}>Tentar novamente</Button>}
    </div>
  );
}
