import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { AppShell } from "@/components/app/AppShell";

/** Aplicação aberta: sem login. Os dados ficam no navegador do usuário. */
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  component: AuthenticatedLayout,
});

/** Onboarding is a focused, shell-less flow; everything else lives inside the app shell. */
const BARE_PREFIXES = ["/onboarding"];

function AuthenticatedLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (BARE_PREFIXES.some((p) => pathname.startsWith(p))) return <Outlet />;
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
