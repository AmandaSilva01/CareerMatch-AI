/**
 * Data layer — typed queries/mutations against the local browser store.
 * No accounts: everything is kept on the visitor's own device.
 */
import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { local, type TableName } from "@/lib/data/local-store";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import type { ATSResult, MatchResult, ParsedJob, ProfileSnapshot, ResumeContent } from "@/lib/ai/schemas";

export type Profile = Tables<"profiles">;
export type Experience = Tables<"experiences">;
export type Education = Tables<"education">;
export type Skill = Tables<"skills">;
export type Job = Omit<Tables<"jobs">, "parsed_data"> & { parsed_data: ParsedJob | null };
export type Match = Omit<Tables<"matches">, "analysis" | "breakdown"> & { analysis: MatchResult };
export type Resume = Omit<Tables<"resumes">, "content" | "ats_analysis"> & {
  content: ResumeContent;
  ats_analysis: ATSResult | null;
};
export type Application = Tables<"applications">;

const byDesc = (key: "created_at" | "updated_at") => (a: Record<string, unknown>, b: Record<string, unknown>) =>
  String(b[key] ?? "").localeCompare(String(a[key] ?? ""));
const byAsc = (a: { created_at: string }, b: { created_at: string }) => a.created_at.localeCompare(b.created_at);

/* ---------- Profile ---------- */
export const profileQuery = queryOptions({
  queryKey: ["profile"],
  queryFn: async () => local.profile() as Profile | null,
});
export const experiencesQuery = queryOptions({
  queryKey: ["experiences"],
  queryFn: async () =>
    [...local.list("experiences")].sort(
      (a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0) || byAsc(a, b),
    ) as Experience[],
});
export const educationQuery = queryOptions({
  queryKey: ["education"],
  queryFn: async () => [...local.list("education")].sort(byAsc) as Education[],
});
export const skillsQuery = queryOptions({
  queryKey: ["skills"],
  queryFn: async () => [...local.list("skills")].sort(byAsc) as Skill[],
});
export const jobsQuery = queryOptions({
  queryKey: ["jobs"],
  queryFn: async () => [...local.list("jobs")].sort(byDesc("created_at")) as unknown as Job[],
});
export const matchesQuery = queryOptions({
  queryKey: ["matches"],
  queryFn: async () => [...local.list("matches")].sort(byDesc("created_at")) as unknown as Match[],
});
export const resumesQuery = queryOptions({
  queryKey: ["resumes"],
  queryFn: async () => [...local.list("resumes")].sort(byDesc("updated_at")) as unknown as Resume[],
});
export const applicationsQuery = queryOptions({
  queryKey: ["applications"],
  queryFn: async () => [...local.list("applications")].sort(byDesc("created_at")) as Application[],
});

export function useProfile() {
  return useQuery(profileQuery);
}
export function useProfileBundle() {
  const profile = useQuery(profileQuery);
  const experiences = useQuery(experiencesQuery);
  const education = useQuery(educationQuery);
  const skills = useQuery(skillsQuery);
  const loading = profile.isLoading || experiences.isLoading || education.isLoading || skills.isLoading;
  return { profile: profile.data ?? null, experiences: experiences.data ?? [], education: education.data ?? [], skills: skills.data ?? [], loading };
}

export function toProfileSnapshot(b: {
  profile: Profile | null;
  experiences: Experience[];
  education: Education[];
  skills: Skill[];
}): ProfileSnapshot {
  const p = b.profile;
  return {
    fullName: p?.full_name ?? null,
    email: p?.email ?? null,
    phone: p?.phone ?? null,
    city: p?.city ?? null,
    linkedin: p?.linkedin ?? null,
    github: p?.github ?? null,
    portfolio: p?.portfolio ?? null,
    headline: p?.headline ?? null,
    summary: p?.summary ?? null,
    targetRole: p?.target_role ?? null,
    seniority: p?.seniority ?? null,
    experiences: b.experiences.map((e) => ({
      company: e.company,
      role: e.role,
      startDate: e.start_date,
      endDate: e.end_date,
      isCurrent: e.is_current,
      description: e.description,
      achievements: e.achievements ?? [],
    })),
    education: b.education.map((e) => ({
      institution: e.institution,
      course: e.course,
      degree: e.degree,
      startDate: e.start_date,
      endDate: e.end_date,
    })),
    skills: b.skills.map((s) => ({ name: s.name, category: s.category, level: s.level ?? null })),
  };
}

/** Builds a base resume from the profile snapshot (no AI). */
export function snapshotToResume(s: ProfileSnapshot): ResumeContent {
  const period = (a: string | null, b: string | null, cur?: boolean) =>
    [a, cur ? "Atual" : b].filter(Boolean).join(" – ");
  return {
    fullName: s.fullName ?? "Seu nome",
    headline: s.headline ?? s.targetRole ?? "",
    contact: { city: s.city, email: s.email, phone: s.phone, linkedin: s.linkedin, github: s.github, portfolio: s.portfolio },
    summary: s.summary ?? "",
    experiences: s.experiences.map((e) => ({
      company: e.company,
      role: e.role,
      period: period(e.startDate, e.endDate, e.isCurrent),
      bullets: [...(e.description ? [e.description] : []), ...e.achievements],
    })),
    education: s.education.map((e) => ({ institution: e.institution, course: e.course, degree: e.degree, period: period(e.startDate, e.endDate) })),
    skills: s.skills.filter((k) => k.category === "technical" || k.category === "tool").map((k) => k.name),
    certifications: s.skills.filter((k) => k.category === "certification").map((k) => k.name),
    languages: s.skills.filter((k) => k.category === "language").map((k) => (k.level ? `${k.name} (${k.level})` : k.name)),
  };
}

/* ---------- Generic mutations ---------- */

const queryKeyFor = (t: TableName) => (t === "profiles" ? "profile" : t);

export function useInvalidate() {
  const qc = useQueryClient();
  return (keys: TableName[]) =>
    Promise.all(keys.map((k) => qc.invalidateQueries({ queryKey: [queryKeyFor(k)] })));
}

export function useUpsertProfile() {
  const inv = useInvalidate();
  return useMutation({
    mutationFn: async (patch: TablesUpdate<"profiles">) => local.upsertProfile(patch as Record<string, unknown>),
    onSuccess: () => inv(["profiles"]),
  });
}

export function useInsert<T extends TableName>(table: T) {
  const inv = useInvalidate();
  return useMutation({
    mutationFn: async (row: TablesInsert<T>) => local.insert(table, row as Record<string, unknown>) as Tables<T>,
    onSuccess: () => inv([table]),
  });
}

export function useUpdate<T extends TableName>(table: T) {
  const inv = useInvalidate();
  return useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: TablesUpdate<T> }) =>
      local.update(table, id, patch as Record<string, unknown>) as unknown as Tables<T>,
    onSuccess: () => inv([table]),
  });
}

export function useRemove<T extends TableName>(table: T) {
  const inv = useInvalidate();
  return useMutation({
    mutationFn: async (id: string) => local.remove(table, id),
    onSuccess: () => inv([table]),
  });
}

export type { TableName };

