/** Central brand config — change the product name here and it propagates everywhere. */
export const BRAND = {
  name: "CareerMatch AI",
  shortName: "CareerMatch",
  tagline: "Seu próximo emprego começa com um match inteligente.",
  description:
    "Use IA para descobrir como seu perfil se conecta às vagas e crie currículos personalizados para aumentar a relevância da sua candidatura.",
} as const;
