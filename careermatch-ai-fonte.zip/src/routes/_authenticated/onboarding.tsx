import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, ArrowLeft, Check, Sparkles } from "lucide-react";
import { BRAND } from "@/lib/brand";
import { AREAS, SENIORITIES } from "@/lib/options";
import { useProfile, useProfileBundle, useUpsertProfile } from "@/lib/data/queries";
import { Logo } from "@/components/career/Logo";
import { ResumeImport } from "@/components/career/ResumeImport";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: `Onboarding · ${BRAND.name}` }] }),
  component: Onboarding,
});

const STEPS = ["Sobre você", "Área", "Nível", "Currículo", "Pronto"];

function Onboarding() {
  const { data: profile } = useProfile();
  const upsert = useUpsertProfile();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [objective, setObjective] = useState("");
  const [areas, setAreas] = useState<string[]>([]);
  const [level, setLevel] = useState<string>("");
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (!profile || hydrated) return;
    setName(profile.full_name ?? "");
    setObjective(profile.target_role ?? "");
    setAreas(profile.interest_areas ?? []);
    setLevel(profile.seniority ?? "");
    setHydrated(true);
  }, [profile, hydrated]);

  const next = async () => {
    if (step === 0) await upsert.mutateAsync({ full_name: name, target_role: objective });
    if (step === 1) await upsert.mutateAsync({ interest_areas: areas });
    if (step === 2) await upsert.mutateAsync({ seniority: level });
    setStep((s) => s + 1);
  };
  const finish = async () => {
    await upsert.mutateAsync({ onboarding_completed: true, ai_consent: true });
    navigate({ to: "/vagas" });
  };
  const canNext = step === 0 ? name.trim().length > 1 : step === 1 ? areas.length > 0 : step === 2 ? !!level : true;

  return (
    <div className="min-h-screen bg-background">
      <header className="flex h-14 items-center justify-between px-6">
        <Logo />
        <Link to="/dashboard" className="text-sm text-muted-foreground hover:text-foreground">Pular por agora</Link>
      </header>
      <div className="mx-auto max-w-2xl px-6 py-8">
        <div className="mb-8">
          <div className="mb-2 flex justify-between text-xs text-muted-foreground">
            <span>Etapa {step + 1} de {STEPS.length}</span>
            <span>{STEPS[step]}</span>
          </div>
          <Progress value={((step + 1) / STEPS.length) * 100} className="h-1.5" />
        </div>

        <div key={step} className="surface animate-fade-up p-6 sm:p-8">
          {step === 0 && (
            <StepShell title="Vamos começar por você" desc="Como você quer ser chamada(o) e qual é o seu objetivo agora?">
              <div className="space-y-1.5"><Label>Seu nome</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Amanda Ribeiro" autoFocus /></div>
              <div className="space-y-1.5"><Label>Cargo ou objetivo desejado</Label><Textarea rows={2} value={objective} onChange={(e) => setObjective(e.target.value)} placeholder="Ex.: Analista de Dados Pleno em empresa de tecnologia" /></div>
            </StepShell>
          )}
          {step === 1 && (
            <StepShell title="Em quais áreas você busca oportunidades?" desc="Selecione uma ou mais. Isso orienta as sugestões de vagas.">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {AREAS.map((a) => (
                  <ChoiceChip key={a} active={areas.includes(a)} onClick={() => setAreas((s) => (s.includes(a) ? s.filter((x) => x !== a) : [...s, a]))}>{a}</ChoiceChip>
                ))}
              </div>
            </StepShell>
          )}
          {step === 2 && (
            <StepShell title="Qual é o seu nível atual?" desc="Usamos isso para avaliar a senioridade das vagas em relação ao seu perfil.">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {SENIORITIES.map((s) => <ChoiceChip key={s} active={level === s} onClick={() => setLevel(s)}>{s}</ChoiceChip>)}
              </div>
            </StepShell>
          )}
          {step === 3 && (
            <StepShell title="Importe seu currículo" desc="A IA extrai experiências, formação e competências. Você confirma tudo antes de salvar.">
              <ResumeImport onDone={() => setStep(4)} />
              <button onClick={() => setStep(4)} className="text-sm text-muted-foreground underline-offset-2 hover:underline">Prefiro preencher manualmente depois</button>
            </StepShell>
          )}
          {step === 4 && <SummaryStep onFinish={finish} loading={upsert.isPending} />}

          {step < 3 && (
            <div className="mt-8 flex items-center justify-between">
              <Button variant="ghost" onClick={() => setStep((s) => s - 1)} disabled={step === 0}><ArrowLeft /> Voltar</Button>
              <Button onClick={next} disabled={!canNext || upsert.isPending}>Continuar <ArrowRight /></Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StepShell({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
      </div>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function ChoiceChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-xl border px-3 py-2.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        active ? "border-primary bg-primary-soft text-primary" : "bg-card hover:border-primary-muted hover:bg-accent",
      )}
    >
      {children}
    </button>
  );
}

function SummaryStep({ onFinish, loading }: { onFinish: () => void; loading: boolean }) {
  const b = useProfileBundle();
  const skills = b.skills.filter((s) => s.category === "technical" || s.category === "tool" || s.category === "soft").length;
  const certs = b.skills.filter((s) => s.category === "certification").length;
  const stats = [
    { n: skills, l: "competências" },
    { n: b.experiences.length, l: "experiências" },
    { n: b.education.length, l: "formações" },
    { n: certs, l: "certificações" },
  ];
  return (
    <div className="space-y-6 text-center">
      <span className="mx-auto inline-flex rounded-2xl bg-ai-gradient p-3 text-primary-foreground shadow-glow"><Sparkles className="size-6" /></span>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Seu perfil está pronto para o match</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {b.experiences.length + skills > 0 ? "Isto é o que a IA identificou no seu perfil:" : "Você ainda não importou um currículo — pode fazer isso a qualquer momento em Meu Perfil."}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.l} className="rounded-xl bg-accent p-4">
            <div className="text-2xl font-semibold text-primary tabular-nums">{s.n}</div>
            <div className="text-xs text-muted-foreground">{s.l}</div>
          </div>
        ))}
      </div>
      <p className="text-xs text-subtle">Ao continuar, você autoriza o uso de IA para analisar seu perfil e vagas. Pode revogar em Configurações.</p>
      <Button size="lg" onClick={onFinish} disabled={loading} className="w-full sm:w-auto"><Check /> Explorar vagas</Button>
    </div>
  );
}
