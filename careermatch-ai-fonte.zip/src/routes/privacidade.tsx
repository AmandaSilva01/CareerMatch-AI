import { createFileRoute, Link } from "@tanstack/react-router";
import { BRAND } from "@/lib/brand";
import { Logo } from "@/components/career/Logo";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: `Privacidade e Segurança · ${BRAND.name}` },
      { name: "description", content: "Como o CareerMatch AI protege seus dados de carreira e usa IA de forma responsável." },
      { property: "og:title", content: `Privacidade e Segurança · ${BRAND.name}` },
      { property: "og:description", content: "Como o CareerMatch AI protege seus dados de carreira e usa IA de forma responsável." },
    ],
  }),
  component: Privacy,
});

const SECTIONS = [
  ["Quais dados coletamos", "Dados de conta (e-mail, nome), informações de perfil profissional que você cadastra ou importa (experiências, formação, competências), descrições de vagas que você analisa e os currículos gerados."],
  ["Como usamos a IA", "Seu perfil e a vaga são enviados a um provedor de modelo de linguagem exclusivamente para gerar a análise solicitada (match, currículo, ATS, insights). A IA é instruída a nunca inventar informações e a sinalizar o que não foi identificado no seu perfil. Você pode revogar o consentimento a qualquer momento em Configurações."],
  ["Isolamento por usuário", "Todos os registros são protegidos por políticas de segurança em nível de linha no banco de dados: cada usuário só consegue ler e alterar os próprios dados. Currículos nunca são públicos nem compartilhados."],
  ["Match Score", "O Match Score é uma estimativa de compatibilidade entre seu perfil e os requisitos identificados na vaga. Ele não representa probabilidade de contratação e não deve ser interpretado como garantia."],
  ["Exclusão e portabilidade", "Em Configurações você pode exportar todos os seus dados em JSON ou apagá-los permanentemente."],
  ["Autenticação", "Suporte a e-mail/senha e Google. Senhas nunca são armazenadas em texto puro. Recomendamos ativar senhas fortes e únicas."],
];

function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <header className="mx-auto flex h-16 max-w-3xl items-center justify-between px-6"><Logo /><Link to="/" className="text-sm text-muted-foreground hover:text-foreground">Voltar</Link></header>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="text-3xl font-semibold tracking-tight">Privacidade e Segurança</h1>
        <p className="mt-2 text-muted-foreground">Seus dados de carreira são sensíveis. Veja como cuidamos deles.</p>
        <div className="mt-10 space-y-8">
          {SECTIONS.map(([t, d]) => <section key={t}><h2 className="text-lg font-semibold">{t}</h2><p className="mt-1.5 leading-relaxed text-muted-foreground">{d}</p></section>)}
        </div>
      </main>
    </div>
  );
}
