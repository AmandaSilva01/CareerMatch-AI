/** Core product flow: raw description → parsed job (AI) → saved job → match (AI) → saved match. */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { calculateMatch, parseJob } from "@/lib/ai/ai.functions";
import { local } from "@/lib/data/local-store";
import { toProfileSnapshot, useProfileBundle, type Job, type Match } from "@/lib/data/queries";
import type { MatchResult, ParsedJob } from "@/lib/ai/schemas";

export type AnalyzeStage = "idle" | "parsing" | "matching" | "done" | "error";

export function useAnalyzeJob() {
  const parse = useServerFn(parseJob);
  const match = useServerFn(calculateMatch);
  const bundle = useProfileBundle();
  const qc = useQueryClient();
  const [stage, setStage] = useState<AnalyzeStage>("idle");
  const [error, setError] = useState<string | null>(null);

  const fail = (e: unknown) => {
    setError(e instanceof Error ? e.message : "Não conseguimos concluir a análise agora. Suas informações foram preservadas.");
    setStage("error");
  };

  /** Parses + saves a job. Returns the saved row. */
  async function saveJob(description: string, extra?: { sourceUrl?: string | null }) {
    setStage("parsing");
    setError(null);
    const parsed: ParsedJob = await parse({ data: { description } });
    const data = local.insert("jobs", {
      title: parsed.jobTitle,
      company: parsed.company,
      description,
      location: parsed.location,
      work_model: parsed.workModel,
      seniority: parsed.seniority,
      salary_range: parsed.salaryRange,
      source_url: extra?.sourceUrl ?? null,
      parsed_data: parsed,
    });
    qc.invalidateQueries({ queryKey: ["jobs"] });
    return data as unknown as Job;
  }

  /** Calculates + saves a match for an existing job. */
  async function matchJob(job: Job) {
    if (!job.parsed_data) throw new Error("Vaga sem dados estruturados.");
    setStage("matching");
    setError(null);
    const result: MatchResult = await match({ data: { profile: toProfileSnapshot(bundle), job: job.parsed_data } });
    const data = local.insert("matches", {
      job_id: job.id,
      score: result.score,
      analysis: result,
      breakdown: result.categories,
    });
    qc.invalidateQueries({ queryKey: ["matches"] });
    return data as unknown as Match;
  }

  async function analyze(description: string, extra?: { sourceUrl?: string | null }) {
    try {
      const job = await saveJob(description, extra);
      const m = await matchJob(job);
      setStage("done");
      return { job, match: m };
    } catch (e) {
      fail(e);
      return null;
    }
  }

  async function rematch(job: Job) {
    try {
      const m = await matchJob(job);
      setStage("done");
      return m;
    } catch (e) {
      fail(e);
      return null;
    }
  }

  return { analyze, rematch, stage, error, reset: () => setStage("idle"), profileReady: !bundle.loading && (bundle.experiences.length > 0 || bundle.skills.length > 0) };
}
