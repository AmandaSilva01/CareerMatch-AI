import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, KanbanSquare, Building2, Calendar, FileText, MoreHorizontal, Trash2, ChevronRight, ChevronLeft } from "lucide-react";
import { toast } from "sonner";
import { BRAND } from "@/lib/brand";
import { APPLICATION_STATUSES, type ApplicationStatus } from "@/lib/options";
import { applicationsQuery, jobsQuery, matchesQuery, resumesQuery, useInsert, useRemove, useUpdate, type Application } from "@/lib/data/queries";
import { PageHeader, EmptyState } from "@/components/career/Primitives";
import { MatchPill } from "@/components/career/MatchScore";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export const Route = createFileRoute("/_authenticated/candidaturas")({
  head: () => ({ meta: [{ title: `Candidaturas · ${BRAND.name}` }] }),
  component: Applications,
});

const NONE = "none";

function Applications() {
  const apps = useQuery(applicationsQuery);
  const jobs = useQuery(jobsQuery);
  const matches = useQuery(matchesQuery);
  const resumes = useQuery(resumesQuery);
  const insert = useInsert("applications");
  const update = useUpdate("applications");
  const remove = useRemove("applications");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Application | null>(null);
  const [form, setForm] = useState({ company: "", role: "", job_id: NONE, resume_id: NONE, status: "saved" as ApplicationStatus, applied_at: "", notes: "" });

  const openNew = () => { setEditing(null); setForm({ company: "", role: "", job_id: NONE, resume_id: NONE, status: "saved", applied_at: "", notes: "" }); setOpen(true); };
  const openEdit = (a: Application) => { setEditing(a); setForm({ company: a.company, role: a.role, job_id: a.job_id ?? NONE, resume_id: a.resume_id ?? NONE, status: a.status as ApplicationStatus, applied_at: a.applied_at ?? "", notes: a.notes ?? "" }); setOpen(true); };

  async function save() {
    if (!form.company || !form.role) { toast.error("Empresa e cargo são obrigatórios."); return; }
    const job_id = form.job_id === NONE ? null : form.job_id;
    const match = job_id ? matches.data?.find((m) => m.job_id === job_id) : undefined;
    const patch = { company: form.company, role: form.role, job_id, resume_id: form.resume_id === NONE ? null : form.resume_id, status: form.status, applied_at: form.applied_at || null, notes: form.notes || null, match_score: match?.score ?? editing?.match_score ?? null };
    if (editing) await update.mutateAsync({ id: editing.id, patch });
    else await insert.mutateAsync(patch as never);
    setOpen(false);
    toast.success(editing ? "Candidatura atualizada." : "Candidatura adicionada.");
  }
  const move = (a: Application, dir: 1 | -1) => {
    const idx = APPLICATION_STATUSES.findIndex((s) => s.value === a.status);
    const next = APPLICATION_STATUSES[idx + dir];
    if (next) update.mutate({ id: a.id, patch: { status: next.value, ...(next.value === "applied" && !a.applied_at ? { applied_at: new Date().toISOString().slice(0, 10) } : {}) } });
  };

  return (
    <>
      <PageHeader title="Candidaturas" description="Seu ATS pessoal: acompanhe cada vaga da descoberta à oferta." actions={<Button onClick={openNew}><Plus /> Nova candidatura</Button>} />
      {apps.isLoading && <Skeleton className="h-96 rounded-xl" />}
      {!apps.isLoading && (apps.data ?? []).length === 0 && (
        <EmptyState icon={KanbanSquare} title="Nenhuma candidatura ainda" description="Salve vagas analisadas ou adicione manualmente para acompanhar o progresso." actions={<><Button onClick={openNew}><Plus /> Adicionar</Button><Button asChild variant="outline"><Link to="/vagas">Ver vagas</Link></Button></>} />
      )}
      {!apps.isLoading && (apps.data ?? []).length > 0 && (
        <div className="-mx-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10">
          <div className="flex min-w-max gap-4">
            {APPLICATION_STATUSES.map((s) => {
              const col = (apps.data ?? []).filter((a) => a.status === s.value);
              return (
                <div key={s.value} className="w-72 shrink-0">
                  <div className="mb-3 flex items-center justify-between px-1">
                    <span className="text-sm font-semibold">{s.label}</span>
                    <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground tabular-nums">{col.length}</span>
                  </div>
                  <div className="min-h-32 space-y-3 rounded-xl bg-muted/50 p-2">
                    {col.map((a) => {
                      const resume = resumes.data?.find((r) => r.id === a.resume_id);
                      return (
                        <article key={a.id} className="surface p-4 text-sm">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0"><div className="truncate font-semibold">{a.role}</div><div className="flex items-center gap-1 truncate text-xs text-muted-foreground"><Building2 className="size-3" /> {a.company}</div></div>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="size-7" aria-label="Ações"><MoreHorizontal className="size-4" /></Button></DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openEdit(a)}>Editar</DropdownMenuItem>
                                {a.job_id && <DropdownMenuItem asChild><Link to="/vagas/$jobId" params={{ jobId: a.job_id }}>Ver vaga</Link></DropdownMenuItem>}
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => remove.mutate(a.id)}><Trash2 /> Excluir</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                            {a.match_score !== null && <MatchPill score={a.match_score} />}
                            {a.applied_at && <span className="inline-flex items-center gap-1"><Calendar className="size-3" /> {new Date(a.applied_at + "T00:00").toLocaleDateString("pt-BR")}</span>}
                          </div>
                          {resume && <Link to="/curriculos/$resumeId" params={{ resumeId: resume.id }} className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline"><FileText className="size-3" /> {resume.name}</Link>}
                          <div className="mt-3 flex justify-between border-t pt-2">
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" disabled={s.value === "saved"} onClick={() => move(a, -1)}><ChevronLeft className="size-3.5" /> Voltar</Button>
                            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" disabled={s.value === "closed"} onClick={() => move(a, 1)}>Avançar <ChevronRight className="size-3.5" /></Button>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "Editar candidatura" : "Nova candidatura"}</DialogTitle></DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1 sm:col-span-2"><Label>Vaga analisada (opcional)</Label>
              <Select value={form.job_id} onValueChange={(v) => { const j = jobs.data?.find((x) => x.id === v); setForm((f) => ({ ...f, job_id: v, company: j?.company ?? f.company, role: j?.title ?? f.role })); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value={NONE}>Nenhuma</SelectItem>{(jobs.data ?? []).map((j) => <SelectItem key={j.id} value={j.id}>{j.title}{j.company ? ` · ${j.company}` : ""}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Empresa</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
            <div className="space-y-1"><Label>Cargo</Label><Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} /></div>
            <div className="space-y-1"><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as ApplicationStatus })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{APPLICATION_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="space-y-1"><Label>Data da candidatura</Label><Input type="date" value={form.applied_at} onChange={(e) => setForm({ ...form, applied_at: e.target.value })} /></div>
            <div className="space-y-1 sm:col-span-2"><Label>Currículo utilizado</Label>
              <Select value={form.resume_id} onValueChange={(v) => setForm({ ...form, resume_id: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value={NONE}>Nenhum</SelectItem>{(resumes.data ?? []).map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="space-y-1 sm:col-span-2"><Label>Notas</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button><Button onClick={save}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
